# LifeDrop

Blood-donation coordination platform (Next.js 14 + Supabase). LifeDrop coordinates; the blood bank / facility makes every medical decision.

## Status of this build (read first)
Written but **not yet executed**: the authoring environment had no Postgres, no npm network access and no `node_modules`.
Before relying on anything: apply migrations to a Supabase *branch*, run `npm run test:db`, then `npm i && npm run typecheck && npm run lint && npm run build && npm test`.

Implemented: migrations 0003-0005 (schema, RLS, workflows, staff/admin/push), email-OTP auth, onboarding, donor health questionnaire, requests
(unconfirmed/limited rules, facility confirmation, multi-donor responses, select/withdraw/fulfil/cancel/extend), notifications (in-app + outbox, quiet hours),
facility registration/documents/staff, verification-officer queue, moderator queue, admin console (roles, suspension, audit log, config), account deletion/anonymisation,
real-count landing stats, PWA manifest + service worker + push subscription, Resend email adapter, web-push adapter (both off until configured),
phone-verify and masked-call provider interfaces (SMS/telephony have NO adapter yet and report "not configured").

Not built: Supabase Realtime (pages load on open/reload), SMS and call-masking adapters (need a provider), Telugu (English only by decision), end-to-end browser tests.
Syntax of all 40 TS/TSX files was parsed successfully; type-check, lint, build and the SQL were not run.

## Supabase Auth settings (dashboard)
- Email provider on; edit the "Magic link"/"Confirm signup" templates to show `{{ .Token }}` (6-digit code).
- Email OTP expiry 600 s; OTP length 6; per-email resend interval 60 s; configure rate limits. The UI cooldown is cosmetic; Supabase enforces these.
- Custom SMTP is required for production volume (default sender is heavily rate-limited).
- Add your site URL / redirect URLs.

## First admin / facilities (no fake data is seeded)
```sql
-- after the person has signed up and completed onboarding:
insert into user_roles (user_id, role) values ('<auth user uuid>', 'admin');
-- facilities come from real sources only. Manual add (verified after document review), or load an official registry later:
-- insert into facilities (name, facility_type, address, city, state, location, source, external_registry_id, status, verified_by, verified_at) values (...)
```
ABDM HFR later: load rows with `source = 'abdm_hfr'` and `external_registry_id`; requests reference `facilities.id`, so nothing else changes.

## Operations
- Schedule `GET /api/cron/maintenance` every minute and `GET /api/cron/deliver` every minute with `Authorization: Bearer $CRON_SECRET`
  (Vercel Hobby cron is daily-only; use Vercel Pro, Supabase pg_cron + pg_net, or an external scheduler).
- Set `SUPABASE_SERVICE_ROLE_KEY` only as a server env var.
- Operational defaults awaiting your approval live in `app_config` (marked `[DEFAULT]`).

## Launch blockers (not engineering)
1. Medical review of the questionnaire wording, component list and compatibility chart (`require_reviewed_questionnaire` blocks donor responses until `medically_reviewed = true`).
2. SMS provider (India DLT) and a call-masking provider; until configured the app says so instead of pretending.
3. Legal review: DPDP Act consent, retention, anonymisation rules, emergency messaging.
4. Staffing for verification/moderation/escalation (currently one person).
