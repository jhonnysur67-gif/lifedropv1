// Minimal service worker: push alerts + notification click. No offline caching of data: blood-request information must never be shown stale.
self.addEventListener("push", (e) => {
  let d = { title: "LifeDrop", body: "" };
  try { d = e.data.json(); } catch {}
  e.waitUntil(self.registration.showNotification(d.title, { body: d.body, icon: "/icon.svg", data: { url: "/notifications" } }));
});
self.addEventListener("notificationclick", (e) => {
  e.notification.close();
  e.waitUntil(self.clients.openWindow((e.notification.data && e.notification.data.url) || "/notifications"));
});
