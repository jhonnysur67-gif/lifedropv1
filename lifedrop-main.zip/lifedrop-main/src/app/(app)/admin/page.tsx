"use client";
import { useState } from "react";
import { adminFindUser, setUserRole, setUserSuspended, auditLogs, appConfig, setAppConfig } from "@/lib/data";
import { useAsync, toast } from "@/lib/hooks";
import { Skeleton, ErrorBox, Empty, fmt } from "@/components/ui";

const ROLES = ["verification_officer", "moderator", "admin"];
export default function Admin() {
  const [tab, setTab] = useState<"users" | "audit" | "config">("users");
  return (
    <div className="mx-auto max-w-2xl space-y-4"><h1 className="text-2xl font-bold">Admin</h1>
      <div className="flex gap-2" role="tablist">{(["users", "audit", "config"] as const).map((t) => <button key={t} role="tab" aria-selected={tab === t} onClick={() => setTab(t)} className={`rounded-full px-4 py-2 text-sm font-medium capitalize ${tab === t ? "bg-brand text-white" : "bg-white text-neutral-600"}`}>{t}</button>)}</div>
      {tab === "users" ? <Users /> : tab === "audit" ? <Audit /> : <Config />}</div>
  );
}
function Users() {
  const [email, setEmail] = useState(""); const [reason, setReason] = useState(""); const [res, setRes] = useState<Awaited<ReturnType<typeof adminFindUser>> | null>(null);
  const find = async () => { try { setRes(await adminFindUser(email, reason)); } catch (e) { toast(e instanceof Error ? e.message : "Failed"); } };
  const act = async (fn: () => Promise<unknown>) => { try { await fn(); toast("Done (audited)"); find(); } catch (e) { toast(e instanceof Error ? e.message : "Failed"); } };
  return (
    <div className="space-y-3"><div className="card space-y-2"><p className="text-sm text-neutral-600">Look up one account by exact email. Every lookup is audited.</p>
      <input className="input" type="email" placeholder="Exact email" aria-label="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
      <input className="input" placeholder="Reason for lookup / action (required)" aria-label="Reason" value={reason} onChange={(e) => setReason(e.target.value)} />
      <button className="btn w-full" onClick={find}>Look up</button></div>
      {res && (res.length ? res.map((u) => (<div key={u.user_id} className="card space-y-2 text-sm"><p className="font-semibold">{u.name} · {u.donor_code}</p><p>Roles: {u.roles ?? "none"} · {u.suspended ? "SUSPENDED" : "active"}</p>
        <div className="flex flex-wrap gap-2">{ROLES.map((r) => { const has = (u.roles ?? "").split(",").includes(r); return <button key={r} className="btn-ghost px-3 py-1.5" onClick={() => window.confirm(`${has ? "Revoke" : "Grant"} ${r}?`) && act(() => setUserRole(u.user_id, r, !has, reason))}>{has ? "Revoke" : "Grant"} {r}</button>; })}
          <button className="btn px-3 py-1.5" onClick={() => window.confirm(u.suspended ? "Restore account?" : "Suspend account?") && act(() => setUserSuspended(u.user_id, !u.suspended, reason))}>{u.suspended ? "Restore account" : "Suspend account"}</button></div></div>)) : <Empty title="No account with that email" />)}</div>
  );
}
function Audit() {
  const a = useAsync(() => auditLogs(100));
  if (a.loading) return <Skeleton />; if (a.error) return <ErrorBox msg={a.error} retry={a.reload} />;
  return a.data?.length ? <div className="space-y-2">{a.data.map((l) => <div key={l.id} className="card py-3 text-sm"><p><b>{l.action}</b> · {l.entity_type} {l.entity_id ?? ""}</p><p className="text-xs text-neutral-500">{fmt(l.created_at)} · {l.actor_roles ?? "user/system"}{l.reason ? ` · ${l.reason}` : ""}</p></div>)}</div> : <Empty title="No audit entries yet" />;
}
function Config() {
  const c = useAsync(appConfig); const [edit, setEdit] = useState<Record<string, string>>({});
  if (c.loading) return <Skeleton />; if (c.error) return <ErrorBox msg={c.error} retry={c.reload} />;
  return <div className="space-y-3">{c.data?.map((r) => (<div key={r.key} className="card space-y-2"><p className="font-semibold">{r.key}</p><p className="text-xs text-neutral-500">{r.description}</p>
    <textarea className="input font-mono text-xs" rows={3} value={edit[r.key] ?? JSON.stringify(r.value)} onChange={(e) => setEdit({ ...edit, [r.key]: e.target.value })} />
    <button className="btn-ghost px-4 py-2 text-sm" disabled={edit[r.key] === undefined} onClick={async () => { let v: unknown; try { v = JSON.parse(edit[r.key]); } catch { return toast("Invalid JSON"); } const why = window.prompt("Reason for this change?"); if (!why) return; try { await setAppConfig(r.key, v, why); toast("Saved (audited)"); c.reload(); } catch (e) { toast(e instanceof Error ? e.message : "Failed"); } }}>Save</button></div>))}</div>;
}
