"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { getMe, getDonations, updateProfile, addDonation, getQuestionnaire, ELIGIBILITY_NOTE, type Me } from "@/lib/data";
import { useAsync, toast } from "@/lib/hooks";
import { Skeleton, ErrorBox } from "@/components/ui";

const OPTS = [["available_now", "Available now"], ["available_later", "Available later"], ["not_available", "Not available"]] as const;
export default function Donate() {
  const { data: me, error, loading, reload } = useAsync(getMe);
  const hist = useAsync(getDonations);
  const q = useAsync(getQuestionnaire);
  const [av, setAv] = useState<Me["availability"]>("not_available");
  const [radius, setRadius] = useState(10);
  const [date, setDate] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (me) { setAv(me.availability); setRadius(me.preferred_radius_km); } }, [me]);
  if (loading) return <Skeleton n={2} />;
  if (error || !me) return <ErrorBox msg={error || "Could not load"} retry={reload} />;
  const today = new Date().toISOString().slice(0, 10);
  async function save() {
    setBusy(true);
    try { await updateProfile({ availability: av, preferred_radius_km: radius, is_donor: av !== "not_available" }); toast("Availability updated"); reload(); }
    catch (e) { toast(e instanceof Error ? e.message : "Update failed"); }
    setBusy(false);
  }
  async function log() { if (!date) return toast("Pick a date"); try { await addDonation(date); toast("Donation date added (self-reported)"); setDate(""); hist.reload(); } catch (e) { toast(e instanceof Error ? e.message : "Could not add"); } }
  const answered = !!q.data?.submitted_at;
  return (
    <div className="mx-auto max-w-lg space-y-5">
      <div><h1 className="text-2xl font-bold">Donate blood</h1><p className="text-neutral-500">Choose when you can be alerted. You can still request blood at any time.</p></div>
      <div className="space-y-2" role="radiogroup" aria-label="Availability">{OPTS.map(([v, l]) => <button key={v} type="button" role="radio" aria-checked={av === v} onClick={() => setAv(v)} className={`w-full rounded-xl border px-4 py-3 text-left font-medium ${av === v ? "border-brand bg-brand-soft text-brand" : "border-neutral-200 bg-white"}`}>{l}</button>)}</div>
      <div><p className="mb-2 text-sm font-medium">Distance I can travel</p><div className="flex gap-2">{[5, 10, 25].map((r) => <button key={r} type="button" onClick={() => setRadius(r)} className={`flex-1 rounded-xl border py-3 font-medium ${radius === r ? "border-brand bg-brand-soft text-brand" : "border-neutral-200 bg-white"}`}>{r} km</button>)}</div></div>
      <button className="btn w-full" onClick={save} disabled={busy}>{busy ? "Saving…" : "Save"}</button>
      <div className="card space-y-2"><h2 className="font-semibold">Private health questionnaire</h2>
        <p className="text-sm text-neutral-600">{answered ? "Submitted. You can update it at any time." : "Required before you can respond to a request."} Only the facility involved in a donation you accept can read it.</p>
        <Link href="/profile/health" className="btn-ghost inline-block">{answered ? "Review answers" : "Complete questionnaire"}</Link></div>
      <div className="card space-y-3"><h2 className="font-semibold">Donation history</h2>
        {hist.data?.map((d) => <p key={d.id} className="text-sm">{d.donation_date} <span className="text-xs text-neutral-500">· {d.source === "facility_confirmed" ? "confirmed by facility" : "self-reported"}</span></p>)}
        {hist.data?.length === 0 && <p className="text-sm text-neutral-500">No donations recorded yet.</p>}
        <div className="flex gap-2"><input type="date" className="input" aria-label="Donation date" max={today} value={date} onChange={(e) => setDate(e.target.value)} /><button className="btn-ghost" onClick={log}>Add</button></div>
        <p className="text-xs text-neutral-500">{ELIGIBILITY_NOTE}</p></div>
    </div>
  );
}
