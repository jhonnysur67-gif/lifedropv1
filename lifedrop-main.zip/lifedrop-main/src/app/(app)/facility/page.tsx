"use client";
import { useState } from "react";
import { getMyAccess, registerFacility, uploadFacilityDoc, facilityStaffList, addFacilityStaff, removeFacilityStaff, requestFeed } from "@/lib/data";
import { useAsync, toast, locate } from "@/lib/hooks";
import { Skeleton, ErrorBox, Empty, RequestCard } from "@/components/ui";

const STATUS: Record<string, string> = { pending: "Awaiting document review", verified: "Verified", rejected: "Rejected", suspended: "Suspended" };
export default function FacilityPage() {
  const acc = useAsync(getMyAccess);
  const feed = useAsync(requestFeed);
  const [sel, setSel] = useState<string>("");
  const [showNew, setShowNew] = useState(false);
  if (acc.loading) return <Skeleton n={2} />;
  if (acc.error || !acc.data) return <ErrorBox msg={acc.error} retry={acc.reload} />;
  const facs = acc.data.facilities;
  const cur = facs.find((f) => f.id === (sel || facs[0]?.id));
  return (
    <div className="mx-auto max-w-2xl space-y-5">
      <div className="flex items-center justify-between"><h1 className="text-2xl font-bold">Facility</h1><button className="btn-ghost px-4 py-2 text-sm" onClick={() => setShowNew(!showNew)}>{showNew ? "Close" : "Register a facility"}</button></div>
      {showNew && <RegisterForm onDone={() => { setShowNew(false); acc.reload(); }} />}
      {!facs.length && !showNew && <Empty title="You are not linked to a facility" hint="Register your hospital or blood bank. LifeDrop will review your documents before it can confirm requests." />}
      {facs.length > 1 && <select className="input" value={cur?.id} onChange={(e) => setSel(e.target.value)} aria-label="Facility">{facs.map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}</select>}
      {cur && (<>
        <div className="card"><p className="text-lg font-semibold">{cur.name}</p><p className="text-sm text-neutral-500">{cur.city}, {cur.state}</p>
          <p className="mt-2 text-sm"><b>Status:</b> {STATUS[cur.status] ?? cur.status}</p>
          {cur.rejection_reason && <p className="text-sm text-brand">Rejected: {cur.rejection_reason}</p>}{cur.suspended_reason && <p className="text-sm text-brand">Suspended: {cur.suspended_reason}</p>}</div>
        {cur.status !== "verified" && <DocUpload facilityId={cur.id} />}
        {cur.status === "verified" && (<>
          <section className="space-y-3"><h2 className="font-semibold">Requests at this facility</h2>
            {feed.loading ? <Skeleton n={1} /> : (() => { const rows = (feed.data ?? []).filter((r) => r.is_facility && ["pending_verification", "active", "partially_fulfilled"].includes(r.state)); return rows.length ? rows.map((r) => <RequestCard key={r.id} r={r} />) : <Empty title="No open requests" />; })()}</section>
          <Staff facilityId={cur.id} manager={cur.staff_role === "manager"} /></>)}
      </>)}
    </div>
  );
}

function RegisterForm({ onDone }: { onDone: () => void }) {
  const [f, setF] = useState({ name: "", type: "hospital", address: "", city: "", state: "", pincode: "", phone: "", email: "", lat: 0, lng: 0, has: false });
  const [busy, setBusy] = useState(false);
  const set = (p: Partial<typeof f>) => setF({ ...f, ...p });
  async function go() {
    if (!f.has) return toast("Capture the facility location first (use the button while at the facility).");
    setBusy(true);
    try { await registerFacility(f); toast("Submitted. Now upload your documents."); onDone(); } catch (e) { toast(e instanceof Error ? e.message : "Failed"); }
    setBusy(false);
  }
  return (
    <div className="card space-y-3">
      <input className="input" placeholder="Facility name" aria-label="Facility name" value={f.name} onChange={(e) => set({ name: e.target.value })} />
      <select className="input" aria-label="Type" value={f.type} onChange={(e) => set({ type: e.target.value })}><option value="hospital">Hospital</option><option value="blood_bank">Blood bank</option><option value="clinic">Clinic</option><option value="other">Other</option></select>
      <input className="input" placeholder="Address" aria-label="Address" value={f.address} onChange={(e) => set({ address: e.target.value })} />
      <div className="grid grid-cols-2 gap-2"><input className="input" placeholder="City" aria-label="City" value={f.city} onChange={(e) => set({ city: e.target.value })} /><input className="input" placeholder="State" aria-label="State" value={f.state} onChange={(e) => set({ state: e.target.value })} /></div>
      <input className="input" placeholder="Pincode" aria-label="Pincode" inputMode="numeric" maxLength={6} value={f.pincode} onChange={(e) => set({ pincode: e.target.value.replace(/\D/g, "") })} />
      <input className="input" placeholder="Facility phone (10 digits)" aria-label="Facility phone" inputMode="numeric" maxLength={10} value={f.phone} onChange={(e) => set({ phone: e.target.value.replace(/\D/g, "") })} />
      <input className="input" placeholder="Facility email" aria-label="Facility email" type="email" value={f.email} onChange={(e) => set({ email: e.target.value })} />
      <button className="btn-ghost w-full" onClick={async () => { try { const c = await locate(); set({ lat: c.lat, lng: c.lng, has: true }); } catch (e) { toast(e instanceof Error ? e.message : "Failed"); } }}>{f.has ? "Location captured ✓" : "Capture facility location"}</button>
      <button className="btn w-full" disabled={busy || f.name.trim().length < 3 || !f.address || !f.city || !f.state} onClick={go}>{busy ? "Submitting…" : "Submit for verification"}</button>
    </div>
  );
}

function DocUpload({ facilityId }: { facilityId: string }) {
  const [type, setType] = useState("registration_certificate");
  const [busy, setBusy] = useState(false);
  return (
    <div className="card space-y-3"><h2 className="font-semibold">Verification documents</h2>
      <p className="text-sm text-neutral-600">Upload your licence or registration (PDF, JPG or PNG, max 5 MB). Only you and LifeDrop verification staff can open them.</p>
      <select className="input" value={type} onChange={(e) => setType(e.target.value)} aria-label="Document type"><option value="registration_certificate">Registration certificate</option><option value="blood_bank_licence">Blood bank licence</option><option value="other">Other</option></select>
      <input type="file" accept="application/pdf,image/jpeg,image/png" aria-label="Document file" disabled={busy} onChange={async (e) => { const file = e.target.files?.[0]; if (!file) return; setBusy(true); try { await uploadFacilityDoc(facilityId, type, file); toast("Uploaded"); } catch (er) { toast(er instanceof Error ? er.message : "Upload failed"); } setBusy(false); e.target.value = ""; }} /></div>
  );
}

function Staff({ facilityId, manager }: { facilityId: string; manager: boolean }) {
  const { data, reload } = useAsync(() => facilityStaffList(facilityId), [facilityId]);
  const [email, setEmail] = useState("");
  return (
    <section className="card space-y-3"><h2 className="font-semibold">Staff</h2>
      {data?.map((s) => <div key={s.user_id} className="flex items-center justify-between text-sm"><span>{s.first_name}{s.is_me && " (you)"} · {s.staff_role}</span>
        {manager && !s.is_me && <button className="text-brand" onClick={async () => { if (!window.confirm("Remove this staff member?")) return; try { await removeFacilityStaff(facilityId, s.user_id); reload(); } catch (e) { toast(e instanceof Error ? e.message : "Failed"); } }}>Remove</button>}</div>)}
      {manager && (<div className="flex gap-2"><input className="input" type="email" placeholder="Staff member's LifeDrop email" aria-label="Staff email" value={email} onChange={(e) => setEmail(e.target.value)} />
        <button className="btn-ghost" onClick={async () => { try { await addFacilityStaff(facilityId, email); toast("If that account exists, it was added."); setEmail(""); reload(); } catch (e) { toast(e instanceof Error ? e.message : "Failed"); } }}>Add</button></div>)}</section>
  );
}
