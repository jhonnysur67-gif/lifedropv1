import { redirect } from "next/navigation";
// The anonymous donor directory was removed (scraping / location-inference surface). People who need blood create a request.
export default function Find() { redirect("/requests"); }
