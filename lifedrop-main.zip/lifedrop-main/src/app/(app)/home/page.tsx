"use client";
import Link from "next/link";
import { getMe, requestFeed } from "@/lib/data";
import { useAsync } from "@/lib/hooks";
import { Skeleton, ErrorBox, Empty, RequestCard } from "@/components/ui";

export default function Home() {
  const me = useAsync(getMe);
  const reqs = useAsync(requestFeed);
  const open = (reqs.data ?? []).filter((r) => ["pending_verification", "active", "partially_fulfilled"].includes(r.state));
  const mine = open.filter((r) => r.is_mine), nearby = open.filter((r) => !r.is_mine).slice(0, 5);
  return (
    <div className="space-y-6">
      <header><p className="text-sm text-neutral-500">{me.data?.area_label}</p><h1 className="text-2xl font-bold">{me.data ? `Hello, ${(me.data.name ?? "").split(" ")[0]}` : "Hello"}</h1>
        {me.data && <div className="mt-2 flex flex-wrap gap-2 text-sm"><span className="rounded-full bg-brand-soft px-3 py-1 font-semibold text-brand">{me.data.blood_group} · {me.data.blood_group_verified_at ? "verified" : "unverified"}</span>
          {me.data.is_donor && <span className="rounded-full bg-green-50 px-3 py-1 text-green-700">Donor · {me.data.availability.replace("_", " ")}</span>}</div>}</header>
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="card bg-brand-soft"><h2 className="font-bold">Need blood?</h2><p className="mb-4 text-sm text-neutral-600">Create a request at a verified hospital or blood bank.</p><Link href="/requests/new" className="btn">Request blood</Link></div>
        <div className="card"><h2 className="font-bold">Donate blood</h2><p className="mb-4 text-sm text-neutral-600">Set your availability and complete your health questionnaire.</p><Link href="/donate" className="btn-ghost">Donor settings</Link></div>
      </div>
      {mine.length > 0 && <section><h2 className="mb-3 font-semibold">Your open requests</h2><div className="grid gap-3 md:grid-cols-2">{mine.map((r) => <RequestCard key={r.id} r={r} />)}</div></section>}
      <section><div className="mb-3 flex justify-between"><h2 className="font-semibold">Requests you can help with</h2><Link href="/requests" className="text-sm text-brand">View all</Link></div>
        {reqs.loading ? <Skeleton n={2} /> : reqs.error ? <ErrorBox msg={reqs.error} retry={reqs.reload} /> :
          nearby.length ? <div className="grid gap-3 md:grid-cols-2">{nearby.map((r) => <RequestCard key={r.id} r={r} />)}</div> :
          <Empty title="No matching requests right now" hint={me.data?.is_donor ? "Requests near you that match your blood group will appear here." : "Turn on donor availability in Donate to see requests you can help with."} />}</section>
    </div>
  );
}
