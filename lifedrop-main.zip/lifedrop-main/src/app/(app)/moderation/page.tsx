"use client";
import Link from "next/link";
import { useState } from "react";
import { moderationQueue, moderateReport } from "@/lib/data";
import { useAsync, toast } from "@/lib/hooks";
import { Skeleton, ErrorBox, Empty, fmt } from "@/components/ui";

export default function Moderation() {
  const q = useAsync(moderationQueue);
  const [reason, setReason] = useState<Record<string, string>>({});
  if (q.loading) return <Skeleton />;
  if (q.error) return <ErrorBox msg={q.error.includes("Not allowed") ? "You do not have access to this page." : q.error} retry={q.reload} />;
  const act = async (id: string, a: "resolve" | "dismiss" | "cancel_request") => {
    const r = (reason[id] ?? "").trim(); if (r.length < 5) return toast("Enter a reason (5+ characters).");
    if (a === "cancel_request" && !window.confirm("Cancel this request? Donors will be notified.")) return;
    try { await moderateReport(id, a, r); toast("Recorded"); q.reload(); } catch (e) { toast(e instanceof Error ? e.message : "Failed"); }
  };
  return (
    <div className="mx-auto max-w-2xl space-y-4"><h1 className="text-2xl font-bold">Reports</h1>
      <p className="text-sm text-neutral-500">Reports never hide a request automatically. Phone numbers and patient details are not shown here.</p>
      {q.data?.length ? q.data.map((i) => (
        <div key={i.report_id} className="card space-y-2">
          <div className="flex flex-wrap items-center gap-2 text-xs">{i.priority && <span className="rounded bg-brand-soft px-2 py-0.5 font-bold text-brand">Priority · {i.distinct_reporters} reporters</span>}<span className="text-neutral-500">{fmt(i.reported_at)}</span></div>
          <p className="font-semibold">{i.reason.replace("_", " ")}</p>{i.details && <p className="text-sm text-neutral-600">{i.details}</p>}
          <p className="text-sm">{i.blood_group} · {i.units} unit(s) · {i.facility_name} · {i.request_state} · {i.confirmed ? "facility-confirmed" : "unconfirmed"}</p>
          <Link href={`/requests/${i.request_id}`} className="text-sm text-brand underline">View request</Link>
          <textarea className="input" rows={2} placeholder="Reason for your decision (recorded in the audit log)" value={reason[i.report_id] ?? ""} onChange={(e) => setReason({ ...reason, [i.report_id]: e.target.value })} />
          <div className="flex flex-wrap gap-2"><button className="btn-ghost px-4 py-2 text-sm" onClick={() => act(i.report_id, "dismiss")}>Dismiss</button><button className="btn-ghost px-4 py-2 text-sm" onClick={() => act(i.report_id, "resolve")}>Resolve</button><button className="btn px-4 py-2 text-sm" onClick={() => act(i.report_id, "cancel_request")}>Cancel request</button></div></div>))
        : <Empty title="No open reports" />}</div>
  );
}
