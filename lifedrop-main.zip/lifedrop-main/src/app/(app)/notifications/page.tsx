"use client";
import Link from "next/link";
import { getNotifications, markNotificationsRead } from "@/lib/data";
import { useAsync } from "@/lib/hooks";
import { Skeleton, ErrorBox, Empty, fmt } from "@/components/ui";

export default function Notifications() {
  const { data, error, loading, reload } = useAsync(getNotifications);
  const unread = data?.filter((n) => !n.read_at).length ?? 0;
  return (
    <div className="mx-auto max-w-lg space-y-4">
      <div className="flex items-center justify-between"><h1 className="text-2xl font-bold">Notifications</h1>
        {unread > 0 && <button className="text-sm text-brand" onClick={async () => { await markNotificationsRead(null); reload(); }}>Mark all read</button>}</div>
      {loading ? <Skeleton /> : error ? <ErrorBox msg={error} retry={reload} /> : data?.length ? data.map((n) => (
        <Link key={n.id} href={n.request_id ? `/requests/${n.request_id}` : "#"} onClick={() => !n.read_at && markNotificationsRead([n.id])} className={`card block ${n.read_at ? "" : "border-brand/40"}`}>
          <p className="font-semibold">{n.title}</p>{n.body && <p className="text-sm text-neutral-600">{n.body}</p>}<p className="text-xs text-neutral-400">{fmt(n.created_at)}</p></Link>
      )) : <Empty title="No notifications yet" hint="Alerts about requests near you and responses to your requests appear here." />}
    </div>
  );
}
