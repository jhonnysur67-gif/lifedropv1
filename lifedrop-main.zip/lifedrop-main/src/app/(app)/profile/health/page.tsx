"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { getQuestionnaire, submitQuestionnaire } from "@/lib/data";
import { useAsync, toast } from "@/lib/hooks";
import { Skeleton, ErrorBox, Empty } from "@/components/ui";

export default function Health() {
  const router = useRouter();
  const { data, error, loading, reload } = useAsync(getQuestionnaire);
  const [a, setA] = useState<Record<string, { v: string; d?: string }>>({});
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (data?.answers) setA(data.answers); }, [data]);
  if (loading) return <Skeleton n={3} />;
  if (error) return <ErrorBox msg={error} retry={reload} />;
  if (!data) return <Empty title="No questionnaire is available" hint="An administrator has not activated one yet." />;
  const qs = data.template.questions;
  async function save() {
    const missing = qs.find((q) => q.type === "yes_no" && !a[q.id]?.v);
    if (missing) return toast("Please answer every question.");
    setBusy(true);
    try { await submitQuestionnaire(a); toast("Saved"); router.push("/donate"); } catch (e) { toast(e instanceof Error ? e.message : "Could not save"); }
    setBusy(false);
  }
  return (
    <div className="mx-auto max-w-lg space-y-5">
      <div><h1 className="text-2xl font-bold">Health &amp; safety questionnaire</h1>
        <p className="text-sm text-neutral-500">Private. Never shown to requesters or other donors. LifeDrop does not decide whether you can donate; the blood bank does.</p></div>
      {!data.template.medically_reviewed && <p role="note" className="card border-amber-300 bg-amber-50 text-sm text-amber-900">Draft wording pending medical review. Donor responses stay paused until a qualified professional has reviewed this questionnaire.</p>}
      {qs.map((q) => (
        <div key={q.id} className="card space-y-2"><p className="font-medium">{q.label}</p>
          {q.type === "yes_no" ? (<div className="flex gap-2">{["yes", "no"].map((v) => <button key={v} type="button" onClick={() => setA({ ...a, [q.id]: { ...a[q.id], v } })} className={`flex-1 rounded-xl border py-2 font-medium capitalize ${a[q.id]?.v === v ? "border-brand bg-brand-soft text-brand" : "border-neutral-200"}`}>{v}</button>)}</div>)
            : <textarea className="input" rows={3} maxLength={500} value={a[q.id]?.v ?? ""} onChange={(e) => setA({ ...a, [q.id]: { v: e.target.value } })} />}
          {q.details_if_yes && a[q.id]?.v === "yes" && <textarea className="input" rows={2} maxLength={300} placeholder="Details (optional)" value={a[q.id]?.d ?? ""} onChange={(e) => setA({ ...a, [q.id]: { v: "yes", d: e.target.value } })} />}</div>))}
      <button className="btn w-full" onClick={save} disabled={busy}>{busy ? "Saving…" : "Save answers"}</button>
    </div>
  );
}
