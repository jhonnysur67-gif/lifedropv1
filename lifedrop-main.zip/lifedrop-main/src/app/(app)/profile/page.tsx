"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { getMe, updateProfile, signOut, deleteAccount, setMyArea, getMyAccess, savePushSubscription, ELIGIBILITY_NOTE } from "@/lib/data";
import { useAsync, toast, locate } from "@/lib/hooks";
import { Skeleton, ErrorBox } from "@/components/ui";
import PhoneVerify from "@/components/PhoneVerify";
import { isIndianMobile } from "@/lib/validation";

export default function Profile() {
  const router = useRouter();
  const { data: me, error, loading, reload } = useAsync(getMe);
  const access = useAsync(getMyAccess);
  const [f, setF] = useState({ name: "", area: "", phone: "" });
  const [del, setDel] = useState("");
  const [showDel, setShowDel] = useState(false);
  useEffect(() => { if (me) setF({ name: me.name ?? "", area: me.area_label ?? "", phone: (me.phone ?? "").replace("+91", "") }); }, [me]);
  if (loading) return <Skeleton n={2} />;
  if (error || !me) return <ErrorBox msg={error || "Could not load"} retry={reload} />;
  async function save() {
    if (f.name.trim().length < 2) return toast("Enter your name");
    if (!isIndianMobile(f.phone)) return toast("Enter a valid 10-digit mobile number");
    try { await updateProfile({ name: f.name.trim(), area_label: f.area.trim(), phone: `+91${f.phone}` }); toast("Profile updated"); reload(); } catch (e) { toast(e instanceof Error ? e.message : "Failed"); }
  }
  async function refreshArea() { try { const c = await locate(); await setMyArea(f.area.trim() || me!.area_label || "My area", c); toast("Approximate area updated"); } catch (e) { toast(e instanceof Error ? e.message : "Failed"); } }
  async function enablePush() {
    const key = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY;
    if (!key || !("serviceWorker" in navigator) || !("PushManager" in window)) return toast("Push alerts are not available on this device or are not configured yet.");
    try {
      if ((await Notification.requestPermission()) !== "granted") return toast("Notification permission was not granted.");
      const reg = await navigator.serviceWorker.ready;
      const raw = atob(key.replace(/-/g, "+").replace(/_/g, "/")); const arr = Uint8Array.from(raw, (c) => c.charCodeAt(0));
      const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: arr });
      await savePushSubscription(sub.toJSON()); toast("Push alerts enabled on this device");
    } catch (e) { toast(e instanceof Error ? e.message : "Could not enable push"); }
  }
  async function out() { await signOut(); router.replace("/login"); router.refresh(); }
  async function remove() { try { await deleteAccount(del); router.replace("/"); router.refresh(); } catch (e) { toast(e instanceof Error ? e.message : "Failed"); } }
  return (
    <div className="mx-auto max-w-lg space-y-5">
      <div className="card"><h1 className="text-xl font-bold">{me.name}</h1>
        <p className="text-sm text-neutral-500">Donor number {me.donor_code} (only you can see this) · {me.blood_group} <b>{me.blood_group_verified_at ? "verified" : "unverified"}</b></p>
        <p className="mt-1 text-xs text-neutral-500">{ELIGIBILITY_NOTE}</p></div>
      <section className="card space-y-3"><h2 className="font-semibold">Personal information</h2>
        <input className="input" aria-label="Name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        <input className="input" aria-label="Mobile number" inputMode="numeric" maxLength={10} value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value.replace(/\D/g, "") })} />
        <p className="text-xs text-neutral-500">Phone: {me.phone_verified_at ? "verified" : "not verified yet. You'll verify it when you respond to a request."} Changing it resets verification.</p>
        <input className="input" aria-label="Area" value={f.area} onChange={(e) => setF({ ...f, area: e.target.value })} />
        <button className="btn-ghost w-full" onClick={refreshArea}>Update approximate area from my location</button>
        <button className="btn w-full" onClick={save}>Save changes</button></section>
      {!me.phone_verified_at && me.phone && <PhoneVerify onDone={() => { toast("Phone verified"); reload(); }} />}
      <section className="card space-y-2 text-sm"><h2 className="font-semibold">Alerts</h2>
        {([["notify_email", "Email alerts"], ["notify_push", "Push alerts"]] as const).map(([k, l]) => <label key={k} className="flex items-center justify-between"><span>{l}</span>
          <input type="checkbox" checked={me[k]} onChange={async (e) => { await updateProfile({ [k]: e.target.checked }); reload(); }} /></label>)}
        <button className="btn-ghost w-full" onClick={enablePush}>Enable push alerts on this device</button>
        <p className="text-xs text-neutral-500">Quiet hours are 10 PM to 7 AM. Only facility-confirmed urgent requests can alert you then. In-app notifications are always available.</p></section>
      <div className="card divide-y divide-neutral-100 text-sm"><Link href="/donate" className="block py-3">Donor settings &amp; history</Link><Link href="/profile/health" className="block py-3">Health questionnaire (private)</Link><Link href="/notifications" className="block py-3">Notifications</Link>
        <Link href="/facility" className="block py-3">Facility (hospital / blood bank staff)</Link>
        {access.data?.roles.includes("verification_officer") || access.data?.roles.includes("admin") ? <Link href="/verification" className="block py-3">Facility verification</Link> : null}
        {access.data?.roles.includes("moderator") || access.data?.roles.includes("admin") ? <Link href="/moderation" className="block py-3">Moderation</Link> : null}
        {access.data?.roles.includes("admin") ? <Link href="/admin" className="block py-3">Admin</Link> : null}</div>
      <button className="w-full py-3 font-semibold text-brand" onClick={out}>Log out</button>
      <section className="card space-y-3 border-brand/30"><h2 className="font-semibold">Delete account</h2>
        <p className="text-sm text-neutral-600">Permanently deletes your account and personal data. Open requests are closed and records that must be kept are anonymised. This cannot be undone.</p>
        {!showDel ? <button className="btn-ghost w-full" onClick={() => setShowDel(true)}>Delete my account…</button> : (<>
          <input className="input" placeholder="Type DELETE to confirm" value={del} onChange={(e) => setDel(e.target.value)} />
          <button className="btn w-full" disabled={del !== "DELETE"} onClick={remove}>Permanently delete</button></>)}</section>
    </div>
  );
}
