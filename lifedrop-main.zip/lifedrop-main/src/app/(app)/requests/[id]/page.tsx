"use client";
import { useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { requestFeed, respondToRequest, withdrawResponse, responsesFor, selectDonor, rejectResponse, cancelRequest, markFulfilled, extendRequest,
  confirmRequest, confirmDonation, reportRequest, contactDonor, type Feed } from "@/lib/data";
import { useAsync, toast } from "@/lib/hooks";
import { Skeleton, ErrorBox, Empty, fmt, dist, VerificationBadge, STATE_LABEL } from "@/components/ui";
import PhoneVerify from "@/components/PhoneVerify";

const OPEN = ["pending_verification", "active", "partially_fulfilled"];
export default function Details() {
  const { id } = useParams<{ id: string }>();
  const { data, error, loading, reload } = useAsync(() => requestFeed(id), [id]);
  const r: Feed | undefined = data?.[0];
  const canSee = !!r && (r.is_mine || r.is_facility);
  const resp = useAsync(() => (canSee ? responsesFor(id) : Promise.resolve([])), [id, canSee]);
  const [busy, setBusy] = useState(false);
  const [needPhone, setNeedPhone] = useState(false);
  const [needQ, setNeedQ] = useState(false);
  const [ext, setExt] = useState("");
  if (loading) return <Skeleton n={2} />;
  if (error) return <ErrorBox msg={error} retry={reload} />;
  if (!r) return <Empty title="Request not found" hint="It may have expired, been closed, or be outside your area." />;
  const open = OPEN.includes(r.state);
  const run = async (fn: () => Promise<unknown>, ok: string) => { setBusy(true); try { await fn(); toast(ok); reload(); resp.reload(); } catch (e) { toast(e instanceof Error ? e.message : "Failed"); } setBusy(false); };
  async function donate() {
    setBusy(true);
    try { await respondToRequest(r!.id); toast("Thank you. The requester can now see your response."); setNeedPhone(false); reload(); }
    catch (e) { const m = e instanceof Error ? e.message : ""; if (m.includes("PHONE_NOT_VERIFIED")) setNeedPhone(true); else if (m.includes("QUESTIONNAIRE_REQUIRED")) setNeedQ(true); else toast(m || "Failed"); }
    setBusy(false);
  }
  async function contact(rid: string) { try { await contactDonor(rid); toast("Connecting your call…"); } catch (e) { toast(e instanceof Error ? e.message : "Could not connect"); } }
  async function share() { const url = location.href; if (navigator.share) await navigator.share({ title: "Blood request on LifeDrop", url }).catch(() => {}); else { await navigator.clipboard.writeText(url); toast("Link copied"); } }
  const canRespond = open && !r.is_mine && !r.my_response;
  return (
    <div className="mx-auto max-w-lg space-y-5">
      <div className="flex flex-wrap items-center gap-2"><VerificationBadge v={r.verification} />{r.is_urgent_verified && <span className="rounded bg-brand-soft px-2 py-0.5 text-xs font-bold text-brand">Urgent</span>}<span className="text-xs text-neutral-500">{STATE_LABEL[r.state] ?? r.state}</span></div>
      <h1 className="text-5xl font-extrabold text-brand">{r.blood_group}</h1>
      <p className="text-xl font-semibold">{r.units_required - r.units_fulfilled} of {r.units_required} unit{r.units_required > 1 ? "s" : ""} still needed</p>
      <div className="card space-y-2 text-sm"><p><b>Facility:</b> {r.facility_name}{r.facility_city ? `, ${r.facility_city}` : ""}</p><p><b>Distance:</b> {dist(r.distance_km)}</p><p><b>Needed:</b> {fmt(r.needed_at)}</p>
        {r.state === "pending_verification" && <p className="text-neutral-600">Not yet confirmed by the facility. Expires {fmt(r.expires_at)} unless confirmed. Please check with the facility before travelling.</p>}
        {r.additional_information && <p><b>Notes:</b> {r.additional_information}</p>}</div>

      {r.needs_renewal && r.is_mine && (<div className="card space-y-2 border-brand/40"><p className="font-semibold">Is blood still needed?</p>
        <input type="datetime-local" className="input" value={ext} onChange={(e) => setExt(e.target.value)} />
        <div className="flex gap-2"><button className="btn flex-1" disabled={busy || !ext} onClick={() => run(() => extendRequest(r.id, ext), "Request extended")}>Yes, extend</button>
          <button className="btn-ghost flex-1" disabled={busy} onClick={() => run(() => cancelRequest(r.id, "no_longer_needed"), "Request closed")}>No longer needed</button></div></div>)}

      {needQ && <div className="card text-sm">Complete your private health questionnaire first. <Link className="text-brand underline" href="/profile/health">Open questionnaire</Link></div>}
      {needPhone && <PhoneVerify onDone={() => { setNeedPhone(false); donate(); }} />}
      {!r.is_mine && <button className="btn w-full" disabled={!canRespond || busy} onClick={donate}>{r.my_response === "selected" ? "You were chosen. Expect a call" : r.my_response ? "You've responded ✓" : busy ? "Sending…" : "I can donate"}</button>}
      {!r.is_mine && <p className="text-xs text-neutral-500">Responding does not mean you are eligible. The blood bank or facility decides. Your phone number is never shown to the requester.</p>}
      {r.my_response_id && (r.my_response === "accepted" || r.my_response === "selected") && <button className="w-full py-2 text-sm text-neutral-600 underline" disabled={busy} onClick={() => window.confirm("Withdraw your response?") && run(() => withdrawResponse(r.my_response_id!), "Response withdrawn")}>Withdraw my response</button>}

      {canSee && (<section className="space-y-3"><h2 className="font-semibold">Donors who responded</h2>
        {resp.loading ? <Skeleton n={1} /> : resp.data?.length ? resp.data.map((d) => (
          <div key={d.response_id} className="card space-y-2"><div className="flex items-center justify-between"><div><p className="font-semibold">{d.donor_first_name}</p>
            <p className="text-sm text-neutral-600">{d.blood_group} · <b>{d.blood_group_verified ? "verified" : "unverified"}</b> · about {d.distance_km ?? "?"} km · {d.availability.replace("_", " ")}</p></div>
            <span className="text-xs uppercase text-neutral-500">{d.status}</span></div>
            <div className="flex flex-wrap gap-2">
              {r.is_mine && d.status === "accepted" && <><button className="btn px-4 py-2 text-sm" disabled={busy} onClick={() => run(() => selectDonor(d.response_id), "Donor selected")}>Choose this donor</button><button className="btn-ghost px-4 py-2 text-sm" disabled={busy} onClick={() => run(() => rejectResponse(d.response_id), "Declined")}>Decline</button></>}
              {r.is_mine && d.status === "selected" && <button className="btn px-4 py-2 text-sm" onClick={() => contact(d.response_id)}>Call donor (private)</button>}
              {r.is_facility && (d.status === "accepted" || d.status === "selected") && <button className="btn px-4 py-2 text-sm" disabled={busy} onClick={() => run(() => confirmDonation(d.response_id), "Donation confirmed")}>Confirm donation</button>}</div></div>))
          : <Empty title="No responses yet" hint="Nearby donors have been alerted according to this request's rules. You'll be notified when someone responds." />}</section>)}

      <div className="flex flex-wrap gap-2">
        {r.is_facility && r.state === "pending_verification" && <button className="btn" disabled={busy} onClick={() => run(() => confirmRequest(r.id), "Request confirmed")}>Confirm this request</button>}
        {(r.is_mine || r.is_facility) && open && <><button className="btn-ghost" disabled={busy} onClick={() => window.confirm("Mark this request as fulfilled?") && run(() => markFulfilled(r.id), "Marked fulfilled")}>Mark fulfilled</button>
          <button className="btn-ghost" disabled={busy} onClick={() => window.confirm("Cancel this request?") && run(() => cancelRequest(r.id, "cancelled_by_owner"), "Request cancelled")}>Cancel request</button></>}
        <button className="btn-ghost" onClick={share}>Share</button></div>
      {!r.is_mine && <button className="w-full py-2 text-sm text-neutral-500" onClick={() => { const why = window.prompt("Why are you reporting this? (fake_request, spam, harassment, wrong_details, other)", "fake_request"); if (why) reportRequest(r.id, why, "").then(() => toast("Reported. A moderator will review it.")).catch((e) => toast(e.message)); }}>Report this request</button>}
    </div>
  );
}
