"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { BLOOD_GROUPS, createRequest, searchFacilities, listComponents, type BloodGroup, type Facility } from "@/lib/data";
import { useAsync, toast } from "@/lib/hooks";
import { isIndianMobile, looksLikePhoneInText } from "@/lib/validation";
import { Empty } from "@/components/ui";

const local = (d: Date) => new Date(d.getTime() - d.getTimezoneOffset() * 6e4).toISOString().slice(0, 16);

export default function NewRequest() {
  const router = useRouter();
  const comps = useAsync(listComponents);
  const [q, setQ] = useState("");
  const [results, setResults] = useState<Facility[] | null>(null);
  const [fac, setFac] = useState<Facility | null>(null);
  const [bg, setBg] = useState<BloodGroup>("O+");
  const [units, setUnits] = useState(1);
  const [component, setComponent] = useState("");
  const [needed, setNeeded] = useState(local(new Date(Date.now() + 36e5 * 6)));
  const [phone, setPhone] = useState("");
  const [rel, setRel] = useState("");
  const [patient, setPatient] = useState("");
  const [notes, setNotes] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  useEffect(() => { const t = setTimeout(() => { if (q.trim().length >= 2) searchFacilities(q).then(setResults).catch((e) => setErr(e.message)); else setResults(null); }, 300); return () => clearTimeout(t); }, [q]);

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setErr("");
    if (!fac) return setErr("Choose a verified hospital or blood bank.");
    if (!component) return setErr("Choose the blood component needed.");
    if (!isIndianMobile(phone)) return setErr("Enter a valid 10-digit mobile number.");
    if (rel.trim().length < 2) return setErr("Enter your relationship to the patient.");
    if (new Date(needed).getTime() <= Date.now()) return setErr("Choose a time in the future.");
    if (looksLikePhoneInText(notes)) return setErr("Please don't put phone numbers in notes. Contact is arranged through LifeDrop.");
    setBusy(true);
    try { const id = await createRequest({ facility: fac.id, bg, units, component, needed, phone, relationship: rel.trim(), patient: patient.trim(), notes: notes.trim(), allowCompatible: false }); toast("Request created"); router.push(`/requests/${id}`); }
    catch (e) { setErr(e instanceof Error ? e.message : "Could not create request"); setBusy(false); }
  }
  return (
    <form onSubmit={submit} className="mx-auto max-w-lg space-y-5">
      <div><h1 className="text-2xl font-bold">Request blood</h1>
        <p className="text-neutral-500">Until the facility confirms your request it is labelled &ldquo;Unconfirmed&rdquo;, alerts only nearby donors inside the app, and expires after 2 hours. Please also contact the facility directly.</p></div>
      <div><label className="block text-sm font-medium" htmlFor="fac">Hospital or blood bank (verified only)</label>
        {fac ? <div className="card mt-1 flex items-center justify-between"><div><p className="font-semibold">{fac.name}</p><p className="text-xs text-neutral-500">{fac.address}, {fac.city}, {fac.state}</p></div><button type="button" className="text-sm text-brand" onClick={() => { setFac(null); setQ(""); }}>Change</button></div> : (<>
          <input id="fac" className="input mt-1" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by name or city" />
          {results && (results.length ? <ul className="mt-2 divide-y divide-neutral-100 rounded-xl border border-neutral-200 bg-white">{results.map((f) => <li key={f.id}><button type="button" className="w-full px-4 py-3 text-left" onClick={() => setFac(f)}><p className="font-medium">{f.name}</p><p className="text-xs text-neutral-500">{f.city}, {f.state}</p></button></li>)}</ul>
            : <div className="mt-2"><Empty title="No verified facility matches" hint="Only facilities verified by LifeDrop can be selected. Contact the hospital directly." /></div>)}</>)}</div>
      <div className="grid grid-cols-4 gap-2" role="radiogroup" aria-label="Blood group">{BLOOD_GROUPS.map((b) => <button type="button" key={b} role="radio" aria-checked={bg === b} onClick={() => setBg(b)} className={`rounded-xl border py-3 font-semibold ${bg === b ? "border-brand bg-brand-soft text-brand" : "border-neutral-200 bg-white"}`}>{b}</button>)}</div>
      <div className="card flex items-center justify-between"><span className="font-medium">Units needed</span><div className="flex items-center gap-3"><button type="button" aria-label="Fewer" className="btn-ghost px-4 py-2" onClick={() => setUnits(Math.max(1, units - 1))}>−</button><span className="w-6 text-center text-lg font-bold">{units}</span><button type="button" aria-label="More" className="btn-ghost px-4 py-2" onClick={() => setUnits(Math.min(10, units + 1))}>+</button></div></div>
      <label className="block text-sm font-medium">Component<select className="input mt-1" value={component} onChange={(e) => setComponent(e.target.value)}><option value="">Select…</option>{comps.data?.map((c) => <option key={c.code} value={c.code}>{c.label}</option>)}</select></label>
      <label className="block text-sm font-medium">When needed?<input type="datetime-local" className="input mt-1" min={local(new Date())} value={needed} onChange={(e) => setNeeded(e.target.value)} /></label>
      <label className="block text-sm font-medium">Your mobile number (kept private)<input className="input mt-1" inputMode="numeric" maxLength={10} value={phone} onChange={(e) => setPhone(e.target.value.replace(/\D/g, ""))} /></label>
      <label className="block text-sm font-medium">Relationship to patient<input className="input mt-1" value={rel} onChange={(e) => setRel(e.target.value)} placeholder="e.g. son, friend, hospital staff" /></label>
      <label className="block text-sm font-medium">Patient name (optional, private)<input className="input mt-1" value={patient} onChange={(e) => setPatient(e.target.value)} /></label>
      <label className="block text-sm font-medium">Additional information (optional, visible to nearby donors)<textarea className="input mt-1" rows={3} maxLength={500} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Ward, department, reference. No phone numbers." /></label>
      {err && <p role="alert" className="text-sm text-brand">{err}</p>}
      <button className="btn w-full" disabled={busy}>{busy ? "Creating…" : "Create request"}</button>
    </form>
  );
}
