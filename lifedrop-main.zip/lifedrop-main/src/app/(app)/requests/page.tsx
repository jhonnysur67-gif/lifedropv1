"use client";
import { useState } from "react";
import Link from "next/link";
import { requestFeed } from "@/lib/data";
import { useAsync } from "@/lib/hooks";
import { Skeleton, ErrorBox, Empty, RequestCard } from "@/components/ui";

const OPEN = ["pending_verification", "active", "partially_fulfilled"];
const TABS = ["Open", "Confirmed", "My requests"] as const;
export default function Requests() {
  const [tab, setTab] = useState<(typeof TABS)[number]>("Open");
  const { data, error, loading, reload } = useAsync(requestFeed);
  const rows = (data ?? []).filter((r) => tab === "My requests" ? r.is_mine : OPEN.includes(r.state) && (tab === "Open" || r.verification === "facility_confirmed"));
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between"><h1 className="text-2xl font-bold">Requests</h1><Link href="/requests/new" className="btn px-4 py-2 text-sm">New request</Link></div>
      <div className="flex gap-2 overflow-x-auto" role="tablist">{TABS.map((t) => <button key={t} role="tab" aria-selected={tab === t} onClick={() => setTab(t)} className={`whitespace-nowrap rounded-full px-4 py-2 text-sm font-medium ${tab === t ? "bg-brand text-white" : "bg-white text-neutral-600"}`}>{t}</button>)}</div>
      {loading ? <Skeleton /> : error ? <ErrorBox msg={error} retry={reload} /> : rows.length ? <div className="grid gap-3 md:grid-cols-2">{rows.map((r) => <RequestCard key={r.id} r={r} />)}</div> :
        <Empty title={tab === "My requests" ? "You have not created any requests" : "No requests to show"} hint={tab === "My requests" ? undefined : "Only requests matching your blood group, availability and distance appear here."} />}
    </div>
  );
}
