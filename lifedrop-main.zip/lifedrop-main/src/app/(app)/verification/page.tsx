"use client";
import { useState } from "react";
import { facilitiesForReview, facilityDocs, facilityPrivate, reviewFacility } from "@/lib/data";
import { useAsync, toast } from "@/lib/hooks";
import { Skeleton, ErrorBox, Empty } from "@/components/ui";

const TABS = [["pending", "Pending"], ["verified", "Verified"], ["suspended", "Suspended"], ["rejected", "Rejected"]] as const;
export default function Verification() {
  const [tab, setTab] = useState<string>("pending");
  const list = useAsync(() => facilitiesForReview(tab), [tab]);
  const [open, setOpen] = useState<string>("");
  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <h1 className="text-2xl font-bold">Facility verification</h1>
      <div className="flex gap-2 overflow-x-auto" role="tablist">{TABS.map(([k, l]) => <button key={k} role="tab" aria-selected={tab === k} onClick={() => { setTab(k); setOpen(""); }} className={`rounded-full px-4 py-2 text-sm font-medium ${tab === k ? "bg-brand text-white" : "bg-white text-neutral-600"}`}>{l}</button>)}</div>
      {list.loading ? <Skeleton /> : list.error ? <ErrorBox msg={list.error.includes("permission") ? "You do not have access to this page." : list.error} retry={list.reload} /> :
        list.data?.length ? list.data.map((f) => (
          <div key={f.id} className="card space-y-2"><button className="w-full text-left" onClick={() => setOpen(open === f.id ? "" : f.id)}><p className="font-semibold">{f.name}</p><p className="text-xs text-neutral-500">{f.facility_type} · {f.address}, {f.city}, {f.state} {f.pincode ?? ""}</p></button>
            {open === f.id && <Detail id={f.id} status={tab} done={() => { setOpen(""); list.reload(); }} />}</div>)) : <Empty title={`No ${tab} facilities`} />}
    </div>
  );
}

function Detail({ id, status, done }: { id: string; status: string; done: () => void }) {
  const docs = useAsync(() => facilityDocs(id), [id]);
  const priv = useAsync(() => facilityPrivate(id), [id]);
  const [reason, setReason] = useState("");
  const act = async (a: "approve" | "reject" | "suspend" | "restore") => {
    if ((a === "reject" || a === "suspend") && reason.trim().length < 5) return toast("Enter a reason (5+ characters).");
    if (!window.confirm(`${a} this facility?`)) return;
    try { await reviewFacility(id, a, reason.trim()); toast("Done"); done(); } catch (e) { toast(e instanceof Error ? e.message : "Failed"); }
  };
  return (
    <div className="space-y-3 border-t border-neutral-100 pt-3 text-sm">
      {priv.data && <p>Contact: {priv.data.contact_phone ?? "no phone"} · {priv.data.contact_email ?? "no email"}</p>}
      <div><p className="font-medium">Documents</p>{docs.loading ? <p>Loading…</p> : docs.data?.length ? docs.data.map((d) => <p key={d.id}>{d.doc_type}: {d.url ? <a className="text-brand underline" href={d.url} target="_blank" rel="noreferrer">open (link expires in 5 min)</a> : "unavailable"}</p>) : <p className="text-neutral-500">No documents uploaded. Do not approve without documents.</p>}</div>
      <textarea className="input" rows={2} placeholder="Reason (required to reject or suspend)" value={reason} onChange={(e) => setReason(e.target.value)} />
      <div className="flex flex-wrap gap-2">
        {status === "pending" && <><button className="btn px-4 py-2" onClick={() => act("approve")}>Approve</button><button className="btn-ghost px-4 py-2" onClick={() => act("reject")}>Reject</button></>}
        {status === "verified" && <button className="btn-ghost px-4 py-2" onClick={() => act("suspend")}>Suspend</button>}
        {status === "suspended" && <button className="btn px-4 py-2" onClick={() => act("restore")}>Restore</button>}</div>
    </div>
  );
}
