import { NextResponse } from "next/server";
import { supabaseServer } from "@/lib/supabase/server";
import { supabaseAdmin } from "@/lib/supabase/admin";

export async function POST(req: Request) {
  const sb = supabaseServer();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const { confirm } = await req.json().catch(() => ({ confirm: "" }));
  if (confirm !== "DELETE") return NextResponse.json({ error: "Type DELETE to confirm." }, { status: 400 });
  const admin = supabaseAdmin();
  const { error } = await admin.rpc("anonymize_account", { p_uid: user.id });
  if (error) return NextResponse.json({ error: "Could not prepare deletion. Nothing was deleted." }, { status: 500 });
  // uploaded facility documents belong to facilities, not individuals; personal-uploader links are removed with facility_staff above
  const { error: e2 } = await admin.auth.admin.deleteUser(user.id);   // cascades profile; retained rows are unlinked via ON DELETE SET NULL
  if (e2) return NextResponse.json({ error: "Deletion failed part-way. Contact support before retrying." }, { status: 500 });
  await sb.auth.signOut();
  return NextResponse.json({ ok: true });
}
