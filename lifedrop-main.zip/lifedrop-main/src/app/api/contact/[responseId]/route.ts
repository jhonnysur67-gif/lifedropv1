import { NextResponse } from "next/server";
import { supabaseServer } from "@/lib/supabase/server";
import { supabaseAdmin } from "@/lib/supabase/admin";
import { telephony } from "@/lib/providers";
import { isUuid } from "@/lib/validation";

// Requester asks LifeDrop to connect them with a SELECTED donor through a masked call. Real numbers never leave the server.
export async function POST(_: Request, { params }: { params: { responseId: string } }) {
  if (!isUuid(params.responseId)) return NextResponse.json({ error: "Bad request" }, { status: 400 });
  const { data: { user } } = await supabaseServer().auth.getUser();
  if (!user) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const admin = supabaseAdmin();
  const { data: x } = await admin.from("request_responses").select("id,status,donor_id,request_id").eq("id", params.responseId).maybeSingle();
  const { data: r } = x ? await admin.from("blood_requests").select("id,requester_id,requester_phone,status").eq("id", x.request_id).single() : { data: null };
  if (!x || !r || r.requester_id !== user.id || x.status !== "selected" || !["pending_verification", "active", "partially_fulfilled"].includes(r.status))
    return NextResponse.json({ error: "Not allowed" }, { status: 403 });
  const { data: d } = await admin.from("profiles").select("phone,phone_verified_at").eq("id", x.donor_id).single();
  if (!d?.phone_verified_at || !r.requester_phone) return NextResponse.json({ error: "Donor phone is not verified." }, { status: 409 });
  const res = await telephony().connectMasked(r.requester_phone, d.phone, x.id);
  if (!res.ok) return NextResponse.json({ error: "Masked calling is not available yet because no telephony provider is configured.", code: "TELEPHONY_NOT_CONFIGURED" }, { status: 501 });
  await admin.from("contact_sessions").insert({ request_id: r.id, response_id: x.id, provider: process.env.TELEPHONY_PROVIDER ?? "none", provider_ref: res.providerRef ?? null, status: "connected" });
  return NextResponse.json({ ok: true });
}
