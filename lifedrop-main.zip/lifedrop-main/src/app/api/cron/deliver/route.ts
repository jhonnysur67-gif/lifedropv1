import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/admin";
import { emailDelivery, pushDelivery } from "@/lib/providers";
// Outbox worker. Only 'pending' rows are sent; quiet-hours rows were already marked suppressed by the DB. Nothing is marked sent unless a provider really sent it.
export async function GET(req: Request) {
  if (!process.env.CRON_SECRET || req.headers.get("authorization") !== `Bearer ${process.env.CRON_SECRET}`) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const admin = supabaseAdmin();
  const { data: rows } = await admin.from("notification_deliveries").select("id,channel,attempts,notifications(user_id,title,body)").eq("status", "pending").lt("attempts", 5).limit(100);
  let sent = 0, skipped = 0;
  for (const d of (rows ?? []) as any[]) {
    const prov = d.channel === "email" ? emailDelivery() : pushDelivery();
    const res = await prov.send(d.notifications.user_id, d.notifications.title, d.notifications.body ?? "");
    if (res.ok) { sent++; await admin.from("notification_deliveries").update({ status: "sent", sent_at: new Date().toISOString(), attempts: d.attempts + 1 }).eq("id", d.id); }
    else { skipped++; if (res.reason === "failed") await admin.from("notification_deliveries").update({ attempts: d.attempts + 1, last_error: res.detail ?? "failed" }).eq("id", d.id); }
  }
  return NextResponse.json({ sent, providerNotConfigured: skipped });
}
