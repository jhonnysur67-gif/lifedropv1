import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/admin";
// Schedule every minute (Vercel Cron / external). Expires requests, prompts "still needed?", expands radius, escalates to admins.
export async function GET(req: Request) {
  if (!process.env.CRON_SECRET || req.headers.get("authorization") !== `Bearer ${process.env.CRON_SECRET}`) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { data, error } = await supabaseAdmin().rpc("run_request_maintenance");
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json(data);
}
