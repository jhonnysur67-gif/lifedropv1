import { NextResponse } from "next/server";
import { createHash, randomInt } from "node:crypto";
import { supabaseServer } from "@/lib/supabase/server";
import { supabaseAdmin } from "@/lib/supabase/admin";
import { sms } from "@/lib/providers";

const hash = (uid: string, code: string) => createHash("sha256").update(`${uid}:${code}:${process.env.SUPABASE_SERVICE_ROLE_KEY}`).digest("hex");

export async function POST() {
  const { data: { user } } = await supabaseServer().auth.getUser();
  if (!user) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const admin = supabaseAdmin();
  const { data: p } = await admin.from("profiles").select("phone,phone_verified_at").eq("id", user.id).single();
  if (!p?.phone) return NextResponse.json({ error: "Add your phone number in your profile first." }, { status: 400 });
  if (p.phone_verified_at) return NextResponse.json({ ok: true, alreadyVerified: true });
  // DB-backed rate limit (serverless-safe): max 5 sends/hour/user, 60 s cooldown
  const since = new Date(Date.now() - 3600e3).toISOString();
  const { data: recent } = await admin.from("phone_verifications").select("created_at").eq("user_id", user.id).gt("created_at", since).order("created_at", { ascending: false });
  if ((recent?.length ?? 0) >= 5) return NextResponse.json({ error: "Too many codes requested. Try again in an hour." }, { status: 429 });
  if (recent?.[0] && Date.now() - new Date(recent[0].created_at).getTime() < 60e3) return NextResponse.json({ error: "Wait 60 seconds before requesting another code." }, { status: 429 });
  const code = String(randomInt(0, 1_000_000)).padStart(6, "0");
  const res = await sms().send(p.phone, `Your LifeDrop verification code is ${code}. It expires in 10 minutes.`);
  if (!res.ok) return NextResponse.json({ error: "SMS verification is not available yet because no SMS provider is configured.", code: "SMS_NOT_CONFIGURED" }, { status: 501 });
  await admin.from("phone_verifications").insert({ user_id: user.id, phone: p.phone, code_hash: hash(user.id, code), expires_at: new Date(Date.now() + 600e3).toISOString() });
  return NextResponse.json({ ok: true });
}
