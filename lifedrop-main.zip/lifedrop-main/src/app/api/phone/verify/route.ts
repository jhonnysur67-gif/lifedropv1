import { NextResponse } from "next/server";
import { createHash, timingSafeEqual } from "node:crypto";
import { supabaseServer } from "@/lib/supabase/server";
import { supabaseAdmin } from "@/lib/supabase/admin";
import { isSixDigitCode } from "@/lib/validation";

const hash = (uid: string, code: string) => createHash("sha256").update(`${uid}:${code}:${process.env.SUPABASE_SERVICE_ROLE_KEY}`).digest("hex");

export async function POST(req: Request) {
  const { data: { user } } = await supabaseServer().auth.getUser();
  if (!user) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const { code } = await req.json().catch(() => ({ code: "" }));
  if (!isSixDigitCode(String(code))) return NextResponse.json({ error: "Enter the 6-digit code." }, { status: 400 });
  const admin = supabaseAdmin();
  const { data: p } = await admin.from("profiles").select("phone").eq("id", user.id).single();
  const { data: v } = await admin.from("phone_verifications").select("*").eq("user_id", user.id).is("verified_at", null).order("created_at", { ascending: false }).limit(1).maybeSingle();
  if (!v || v.phone !== p?.phone || new Date(v.expires_at) < new Date()) return NextResponse.json({ error: "Code expired. Request a new one." }, { status: 400 });
  if (v.attempts >= 5) return NextResponse.json({ error: "Too many attempts. Request a new code." }, { status: 429 });
  await admin.from("phone_verifications").update({ attempts: v.attempts + 1 }).eq("id", v.id);
  const a = Buffer.from(hash(user.id, String(code))), b = Buffer.from(v.code_hash);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return NextResponse.json({ error: "Incorrect code." }, { status: 400 });
  await admin.from("phone_verifications").update({ verified_at: new Date().toISOString() }).eq("id", v.id);
  await admin.from("profiles").update({ phone_verified_at: new Date().toISOString() }).eq("id", user.id).eq("phone", v.phone);
  return NextResponse.json({ ok: true });
}
