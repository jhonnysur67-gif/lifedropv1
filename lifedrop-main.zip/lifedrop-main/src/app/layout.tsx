import "./globals.css";
import PwaRegister from "@/components/PwaRegister";
export const metadata = { title: "LifeDrop", description: "One drop. One life.", manifest: "/manifest.webmanifest" };
export const viewport = { themeColor: "#d62839" };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en"><body>{children}<PwaRegister /></body></html>);
}
