"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { BLOOD_GROUPS, completeProfile, type BloodGroup } from "@/lib/data";
import { isIndianMobile } from "@/lib/validation";

export default function Onboarding() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [f, setF] = useState({ name: "", dob: "", gender: "", bg: "" as BloodGroup | "", phone: "", donor: null as boolean | null, radius: 10, area: "", lat: 0, lng: 0, hasCoords: false });
  const set = (p: Partial<typeof f>) => setF({ ...f, ...p });
  const today = new Date().toISOString().slice(0, 10);

  function next() {
    setErr("");
    if (step === 1 && f.name.trim().length < 2) return setErr("Please enter your full name.");
    if (step === 1 && (!f.dob || f.dob > today)) return setErr("Enter your date of birth.");
    if (step === 2 && !f.bg) return setErr("Select your blood group. You can change it later; it stays 'unverified' until a facility verifies it.");
    if (step === 3 && !isIndianMobile(f.phone)) return setErr("Enter a valid 10-digit mobile number.");
    if (step === 3 && f.donor === null) return setErr("Choose whether you want to donate.");
    setStep(step + 1);
  }
  function locate() {
    navigator.geolocation.getCurrentPosition(
      (p) => set({ lat: p.coords.latitude, lng: p.coords.longitude, hasCoords: true }),
      () => setErr("Location permission denied. You can still type your area, but nearby matching needs a location."));
  }
  async function create() {
    setErr("");
    if (!f.area.trim()) return setErr("Enter your area or city.");
    setBusy(true);
    try {
      await completeProfile({ name: f.name.trim(), dob: f.dob, gender: f.gender, blood_group: f.bg as BloodGroup, phone: f.phone, area: f.area.trim(), is_donor: !!f.donor, radius: f.radius, coords: f.hasCoords ? { lat: f.lat, lng: f.lng } : undefined });
      router.replace("/home"); router.refresh();
    } catch (e) { setErr(e instanceof Error ? e.message : "Something went wrong."); setBusy(false); }
  }
  const opt = (on: boolean) => `rounded-xl border px-4 py-3 text-left font-medium transition ${on ? "border-brand bg-brand-soft text-brand" : "border-neutral-200"}`;
  return (
    <main className="mx-auto min-h-screen max-w-md px-6 py-8">
      <div className="mb-8 flex items-center gap-3"><div className="h-1.5 flex-1 rounded bg-neutral-100"><div className="h-full rounded bg-brand transition-all" style={{ width: `${step * 25}%` }} /></div><span className="text-sm text-neutral-500">{step} of 4</span></div>
      {step === 1 && (<div className="space-y-4"><h1 className="text-2xl font-bold">Tell us about yourself</h1>
        <input className="input" placeholder="Full name" aria-label="Full name" value={f.name} onChange={(e) => set({ name: e.target.value })} />
        <label className="block text-sm font-medium">Date of birth<input type="date" max={today} className="input mt-1" value={f.dob} onChange={(e) => set({ dob: e.target.value })} /></label>
        <div className="flex gap-2">{["Male", "Female", "Other"].map((g) => <button key={g} type="button" className={opt(f.gender === g) + " flex-1"} onClick={() => set({ gender: f.gender === g ? "" : g })}>{g}</button>)}</div>
        <p className="text-xs text-neutral-500">Gender is optional. Your date of birth is private.</p></div>)}
      {step === 2 && (<div><h1 className="mb-1 text-2xl font-bold">What&apos;s your blood group?</h1><p className="mb-4 text-sm text-neutral-500">Self-declared. It is shown as &ldquo;Unverified&rdquo; until a facility verifies it.</p>
        <div className="grid grid-cols-2 gap-3">{BLOOD_GROUPS.map((b) => <button key={b} type="button" className={opt(f.bg === b) + " py-5 text-center text-lg"} onClick={() => set({ bg: b })}>{b}</button>)}</div></div>)}
      {step === 3 && (<div className="space-y-4"><h1 className="text-2xl font-bold">Phone &amp; donating</h1>
        <div className="flex items-center gap-2"><span className="rounded-xl border border-neutral-200 px-3 py-3">+91</span><input className="input" inputMode="numeric" maxLength={10} aria-label="Mobile number" value={f.phone} onChange={(e) => set({ phone: e.target.value.replace(/\D/g, "") })} placeholder="Mobile number" /></div>
        <p className="text-xs text-neutral-500">Never shown to other users. We verify it by SMS only when you respond to a request.</p>
        <button type="button" className={opt(f.donor === true) + " w-full"} onClick={() => set({ donor: true })}>Yes, I&apos;m willing to donate</button>
        <button type="button" className={opt(f.donor === false) + " w-full"} onClick={() => set({ donor: false })}>Not now, I may need to request blood</button>
        {f.donor && (<><p className="text-sm font-medium">Distance I can travel</p><div className="flex gap-2">{[5, 10, 25].map((r) => <button key={r} type="button" className={opt(f.radius === r) + " flex-1 text-center"} onClick={() => set({ radius: r })}>{r} km</button>)}</div>
          <p className="text-xs text-neutral-500">You'll also complete a private health questionnaire before you can respond. Final eligibility is decided by the blood bank.</p></>)}</div>)}
      {step === 4 && (<div className="space-y-4"><h1 className="text-2xl font-bold">Where are you?</h1>
        <p className="text-sm text-neutral-500">We use your location once to pick an approximate area (about 1 km). Your exact position is not stored and is never shown to others.</p>
        <button type="button" className="btn-ghost w-full" onClick={locate}>{f.hasCoords ? "Location captured ✓" : "Use my location"}</button>
        <input className="input" placeholder="Area or city" aria-label="Area or city" value={f.area} onChange={(e) => set({ area: e.target.value })} /></div>)}
      {err && <p role="alert" className="mt-4 text-sm text-brand">{err}</p>}
      <div className="mt-8 flex gap-3">{step > 1 && <button className="btn-ghost" onClick={() => setStep(step - 1)} disabled={busy}>Back</button>}
        {step < 4 ? <button className="btn flex-1" onClick={next}>Next</button> : <button className="btn flex-1" onClick={create} disabled={busy}>{busy ? "Saving…" : "Finish"}</button>}</div>
    </main>
  );
}
