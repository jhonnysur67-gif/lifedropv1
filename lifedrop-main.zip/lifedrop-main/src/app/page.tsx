import Link from "next/link";
import { Droplet, Heart } from "lucide-react";
import { supabaseServer } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";
type Stats = { registered_donors?: number; fulfilled_requests?: number; verified_facilities?: number };

async function loadStats(): Promise<Stats> {
  try { const { data } = await supabaseServer().rpc("public_stats"); return (data ?? {}) as Stats; } catch { return {}; }
}

export default async function Landing() {
  const s = await loadStats();
  // Live database counts only. A figure is rendered only when it is real and non-zero.
  const live = ([["registered_donors", "Registered donors"], ["fulfilled_requests", "Fulfilled requests"], ["verified_facilities", "Verified facilities"]] as const)
    .filter(([k]) => (s[k] ?? 0) > 0).map(([k, l]) => [s[k]!, l] as const);
  return (
    <div>
      <header className="border-b border-neutral-100"><div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
        <span className="flex items-center gap-1.5 text-xl font-bold text-brand"><Droplet fill="currentColor" size={22} />LifeDrop</span>
        <div className="flex gap-2"><Link href="/login" className="btn-ghost px-4 py-2 text-sm">Log in</Link></div></div></header>
      <section className="bg-gradient-to-br from-brand-soft to-white"><div className="mx-auto max-w-6xl px-5 py-14 md:py-24">
        <h1 className="text-5xl font-extrabold leading-[1.05] md:text-6xl">One drop.<br /><span className="text-brand">One life.</span></h1>
        <p className="mt-4 max-w-lg text-lg text-neutral-600">LifeDrop helps people who need blood reach verified hospitals and nearby donors, for emergencies and planned donations.</p>
        <div className="mt-8 flex flex-wrap gap-3"><Link href="/signup" className="btn">Request blood</Link><Link href="/signup" className="btn-ghost bg-white"><Heart size={16} className="mr-2" />Become a donor</Link></div>
        <p className="mt-6 max-w-lg text-sm text-neutral-500">LifeDrop coordinates. It does not give medical advice. The blood bank or hospital decides who can donate and what blood is suitable.</p>
      </div></section>
      {live.length > 0 && (
        <section className="mx-auto max-w-6xl px-5 py-10" aria-label="Live platform counts">
          <div className="grid grid-cols-2 gap-6 md:grid-cols-3">{live.map(([n, l]) => <div key={l}><p className="text-3xl font-extrabold text-brand">{n.toLocaleString("en-IN")}</p><p className="text-sm text-neutral-500">{l}</p></div>)}</div>
          <p className="mt-3 text-xs text-neutral-400">Live counts from the LifeDrop database.</p>
        </section>)}
      <section id="how" className="mx-auto max-w-6xl px-5 pb-16"><h2 className="mb-4 text-xl font-bold">How it works</h2>
        <ol className="grid gap-4 md:grid-cols-3">
          <li className="card"><b>Request</b><p className="text-sm text-neutral-600">Pick a verified hospital or blood bank and say what is needed. The facility confirms the request.</p></li>
          <li className="card"><b>Donors respond</b><p className="text-sm text-neutral-600">Nearby donors are alerted. Unconfirmed requests are labelled as such and reach fewer people.</p></li>
          <li className="card"><b>Private contact</b><p className="text-sm text-neutral-600">You choose who to contact. Phone numbers are never shown; calls are connected privately.</p></li></ol></section>
    </div>
  );
}
