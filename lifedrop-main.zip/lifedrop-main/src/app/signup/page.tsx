import AuthFlow from "@/components/AuthFlow";
export default function Page() { return <AuthFlow mode="signup" />; }
