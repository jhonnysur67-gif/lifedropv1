"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { supabaseBrowser } from "@/lib/supabase/client";
import { isSixDigitCode } from "@/lib/validation";

// Email + 6-digit OTP via Supabase Auth. Expiry (10 min), resend throttle and attempt limits are enforced by Supabase Auth settings
// (see README "Auth configuration"); the UI cooldown below is a convenience, not the security control.
export default function AuthFlow({ mode }: { mode: "login" | "signup" }) {
  const router = useRouter();
  const [step, setStep] = useState<"email" | "otp">("email");
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [wait, setWait] = useState(0);
  const [tries, setTries] = useState(0);

  useEffect(() => { if (wait <= 0) return; const t = setTimeout(() => setWait(wait - 1), 1000); return () => clearTimeout(t); }, [wait]);

  async function send() {
    setErr("");
    const e = email.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) return setErr("Enter a valid email address.");
    setBusy(true);
    const { error } = await supabaseBrowser().auth.signInWithOtp({ email: e, options: { shouldCreateUser: mode === "signup" } });
    setBusy(false);
    if (error) return setErr(mode === "login" && /signups not allowed|not found/i.test(error.message) ? "No account found for this email. Sign up first." : error.message);
    setEmail(e); setStep("otp"); setWait(60); setTries(0); setCode("");
  }
  async function verify() {
    setErr("");
    if (!isSixDigitCode(code)) return setErr("Enter the 6-digit code.");
    if (tries >= 5) return setErr("Too many attempts. Request a new code.");
    setBusy(true); setTries(tries + 1);
    const { error } = await supabaseBrowser().auth.verifyOtp({ email, token: code, type: "email" });
    if (error) { setBusy(false); return setErr("That code is incorrect or has expired."); }
    router.replace("/home"); router.refresh();   // middleware routes new users to /onboarding
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-6">
      <Link href="/" className="mb-8 text-xl font-bold text-brand">LifeDrop</Link>
      {step === "email" ? (<>
        <h1 className="text-2xl font-bold">{mode === "signup" ? "Create your LifeDrop account" : "Welcome back"}</h1>
        <p className="mb-6 mt-1 text-neutral-500">We&apos;ll email you a 6-digit code. No password needed.</p>
        <label className="mb-1 text-sm font-medium" htmlFor="em">Email address</label>
        <input id="em" type="email" autoComplete="email" className="input" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
        {err && <p role="alert" className="mt-2 text-sm text-brand">{err}</p>}
        <button className="btn mt-6" disabled={busy} onClick={send}>{busy ? "Sending…" : "Email me a code"}</button>
        <p className="mt-6 text-center text-sm text-neutral-500">
          {mode === "signup" ? <>Already have an account? <Link className="text-brand" href="/login">Log in</Link></> : <>New here? <Link className="text-brand" href="/signup">Sign up</Link></>}
        </p>
      </>) : (<>
        <h1 className="text-2xl font-bold">Check your email</h1>
        <p className="mb-6 mt-1 text-neutral-500">We sent a 6-digit code to {email}. It expires in 10 minutes.</p>
        <input className="input text-center text-2xl tracking-[0.5em]" inputMode="numeric" maxLength={6} autoComplete="one-time-code" aria-label="6-digit code" value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))} />
        {err && <p role="alert" className="mt-2 text-sm text-brand">{err}</p>}
        <button className="btn mt-6" disabled={busy} onClick={verify}>{busy ? "Verifying…" : "Verify & continue"}</button>
        <button className="mt-4 text-sm text-brand disabled:text-neutral-400" disabled={wait > 0 || busy} onClick={send}>{wait > 0 ? `Resend code in 0:${String(wait).padStart(2, "0")}` : "Resend code"}</button>
        <button className="mt-2 text-sm text-neutral-500" onClick={() => { setStep("email"); setErr(""); }}>Use a different email</button>
      </>)}
    </main>
  );
}
