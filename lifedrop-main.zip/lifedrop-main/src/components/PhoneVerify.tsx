"use client";
import { useState } from "react";
import { startPhoneVerification, verifyPhone } from "@/lib/data";
import { isSixDigitCode } from "@/lib/validation";

export default function PhoneVerify({ onDone }: { onDone: () => void }) {
  const [sent, setSent] = useState(false);
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  async function send() { setBusy(true); setErr(""); try { const r = await startPhoneVerification(); if (r.alreadyVerified) return onDone(); setSent(true); } catch (e) { setErr(e instanceof Error ? e.message : "Failed"); } setBusy(false); }
  async function check() { if (!isSixDigitCode(code)) return setErr("Enter the 6-digit code."); setBusy(true); setErr(""); try { await verifyPhone(code); onDone(); } catch (e) { setErr(e instanceof Error ? e.message : "Failed"); } setBusy(false); }
  return (
    <div className="card space-y-3">
      <h2 className="font-semibold">Verify your phone number</h2>
      <p className="text-sm text-neutral-600">Before you can respond, we verify your number by SMS so requesters can be connected to you. Your number is never shown to anyone.</p>
      {!sent ? <button className="btn w-full" onClick={send} disabled={busy}>{busy ? "Sending…" : "Send SMS code"}</button> : (<>
        <input className="input text-center text-xl tracking-[0.4em]" inputMode="numeric" maxLength={6} aria-label="SMS code" value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))} />
        <button className="btn w-full" onClick={check} disabled={busy}>{busy ? "Checking…" : "Verify"}</button></>)}
      {err && <p role="alert" className="text-sm text-brand">{err}</p>}
    </div>
  );
}
