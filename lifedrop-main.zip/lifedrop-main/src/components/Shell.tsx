"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Home, Droplet, ClipboardList, User, Bell } from "lucide-react";

const NAV = [{ href: "/home", label: "Home", Icon: Home }, { href: "/donate", label: "Donate", Icon: Droplet },
  { href: "/requests", label: "Requests", Icon: ClipboardList }, { href: "/profile", label: "Profile", Icon: User }];

export default function Shell({ children }: { children: React.ReactNode }) {
  const path = usePathname();
  const [msg, setMsg] = useState("");
  const [online, setOnline] = useState(true);
  useEffect(() => {
    const h = (e: Event) => { setMsg((e as CustomEvent).detail); setTimeout(() => setMsg(""), 3000); };
    window.addEventListener("ld-toast", h); return () => window.removeEventListener("ld-toast", h);
  }, []);
  useEffect(() => { setOnline(navigator.onLine); const u = () => setOnline(true), d = () => setOnline(false); window.addEventListener("online", u); window.addEventListener("offline", d); return () => { window.removeEventListener("online", u); window.removeEventListener("offline", d); }; }, []);
  const on = (h: string) => path === h || path.startsWith(h + "/");
  return (
    <div className="min-h-screen bg-neutral-50">
      <header className="sticky top-0 z-20 border-b border-neutral-100 bg-white">
        <div className="mx-auto flex h-14 max-w-5xl items-center justify-between px-4">
          <Link href="/home" className="flex items-center gap-1.5 text-lg font-bold text-brand"><Droplet size={20} fill="currentColor" />LifeDrop</Link>
          <nav className="hidden gap-1 md:flex" aria-label="Main">
            {NAV.map(({ href, label }) => <Link key={href} href={href} className={`rounded-lg px-3 py-2 text-sm font-medium transition ${on(href) ? "bg-brand-soft text-brand" : "text-neutral-600 hover:bg-neutral-100"}`}>{label}</Link>)}
          </nav>
          <Link href="/notifications" aria-label="Notifications" className="rounded-full p-2 hover:bg-neutral-100"><Bell size={20} /></Link>
        </div>
      </header>
      {!online && <p role="status" className="bg-amber-100 px-4 py-2 text-center text-sm text-amber-900">You are offline. Request information may be out of date. Reconnect before acting.</p>}
      <div className="mx-auto max-w-5xl px-4 pb-28 pt-6 md:pb-10">{children}</div>
      <nav aria-label="Main" className="fixed inset-x-0 bottom-0 z-20 grid grid-cols-4 border-t border-neutral-100 bg-white pb-[env(safe-area-inset-bottom)] md:hidden">
        {NAV.map(({ href, label, Icon }) => <Link key={href} href={href} className={`flex flex-col items-center gap-0.5 py-2.5 text-[11px] font-medium ${on(href) ? "text-brand" : "text-neutral-500"}`}><Icon size={22} />{label}</Link>)}
      </nav>
      {msg && <div role="status" className="fixed inset-x-4 bottom-24 z-30 mx-auto max-w-sm rounded-xl bg-neutral-900 px-4 py-3 text-center text-sm text-white shadow-lg md:bottom-8">{msg}</div>}
    </div>
  );
}
