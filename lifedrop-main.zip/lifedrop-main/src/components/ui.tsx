import Link from "next/link";
import type { Feed } from "@/lib/data";
export const Skeleton = ({ n = 3 }: { n?: number }) => <div className="space-y-3">{Array.from({ length: n }, (_, i) => <div key={i} className="h-24 animate-pulse rounded-2xl bg-neutral-100" />)}</div>;
export const ErrorBox = ({ msg, retry }: { msg: string; retry?: () => void }) => <div role="alert" className="card border-brand/30 bg-brand-soft text-sm text-brand">{msg}{retry && <button className="ml-3 underline" onClick={retry}>Retry</button>}</div>;
export const Empty = ({ title, hint }: { title: string; hint?: string }) => <div className="card py-10 text-center"><p className="font-semibold">{title}</p>{hint && <p className="mt-1 text-sm text-neutral-500">{hint}</p>}</div>;
export const fmt = (d: string | Date) => new Date(d).toLocaleString([], { dateStyle: "medium", timeStyle: "short" });
export const dist = (d: number | null) => (d == null ? "Distance unknown" : `${d} km away`);
export const STATE_LABEL: Record<string, string> = { draft: "Draft", pending_verification: "Awaiting facility confirmation", active: "Active", partially_fulfilled: "Partly fulfilled", fulfilled: "Fulfilled", expired: "Expired", cancelled: "Cancelled" };
// Verification is stated plainly: an unconfirmed request is never shown as verified or urgent.
export const VerificationBadge = ({ v }: { v: Feed["verification"] }) => v === "facility_confirmed"
  ? <span className="rounded bg-green-50 px-2 py-0.5 text-xs font-semibold text-green-700">Confirmed by facility</span>
  : <span className="rounded bg-neutral-100 px-2 py-0.5 text-xs font-semibold text-neutral-600">Unconfirmed</span>;
export function RequestCard({ r }: { r: Feed }) {
  return (
    <Link href={`/requests/${r.id}`} className="card flex items-center justify-between gap-3 transition hover:shadow-md">
      <div className="min-w-0">
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <VerificationBadge v={r.verification} />
          {r.is_urgent_verified && <span className="rounded bg-brand-soft px-2 py-0.5 font-bold text-brand">Urgent</span>}
          <span className="text-neutral-500">{STATE_LABEL[r.state] ?? r.state}</span>{r.is_mine && <span className="text-neutral-400">· yours</span>}
        </div>
        <p className="mt-1 text-2xl font-bold text-brand">{r.blood_group} <span className="text-sm font-medium text-neutral-500">{r.units_required - r.units_fulfilled} of {r.units_required} unit{r.units_required > 1 ? "s" : ""} still needed</span></p>
        <p className="truncate text-sm text-neutral-600">{r.facility_name ?? "Facility"}{r.facility_city ? `, ${r.facility_city}` : ""}</p>
        <p className="text-xs text-neutral-500">{dist(r.distance_km)} · needed {fmt(r.needed_at)}</p>
      </div>
      <span className="btn shrink-0 px-4 py-2 text-sm">View</span>
    </Link>
  );
}
