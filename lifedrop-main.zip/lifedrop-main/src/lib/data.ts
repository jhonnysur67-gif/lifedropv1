// Service layer: the only place pages talk to Supabase. No demo data exists anywhere in this app:
// every list comes from the database (RLS + definer RPCs enforce what the caller may see).
import { supabaseBrowser } from "@/lib/supabase/client";

export const BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"] as const;
export type BloodGroup = (typeof BLOOD_GROUPS)[number];
export const ELIGIBILITY_NOTE = "The blood bank/facility determines donor eligibility.";

const sb = () => supabaseBrowser();
async function rpc<T = unknown>(fn: string, args?: Record<string, unknown>): Promise<T> {
  const { data, error } = await sb().rpc(fn, args);
  if (error) throw new Error(error.message);
  return data as T;
}
async function uid() { const { data: { user } } = await sb().auth.getUser(); if (!user) throw new Error("Not signed in"); return user.id; }

// ---------- profile ----------
export type Me = { id: string; name: string | null; gender: string | null; date_of_birth: string | null; blood_group: BloodGroup | null; phone: string | null;
  phone_verified_at: string | null; blood_group_verified_at: string | null; is_donor: boolean; availability: "available_now" | "available_later" | "not_available";
  preferred_radius_km: number; area_label: string | null; donor_code: string; notify_email: boolean; notify_push: boolean; onboarding_completed: boolean };
export async function getMe() {
  const { data, error } = await sb().from("profiles").select("id,name,gender,date_of_birth,blood_group,phone,phone_verified_at,blood_group_verified_at,is_donor,availability,preferred_radius_km,area_label,donor_code,notify_email,notify_push,onboarding_completed").eq("id", await uid()).single();
  if (error) throw new Error(error.message); return data as Me;
}
export type ProfileInput = { name: string; dob: string; gender?: string; blood_group: BloodGroup; phone: string; area: string; is_donor: boolean; radius: number; coords?: { lat: number; lng: number } };
export const completeProfile = (i: ProfileInput) => rpc("complete_profile", { p_name: i.name, p_dob: i.dob, p_gender: i.gender ?? "", p_blood_group: i.blood_group, p_phone: `+91${i.phone}`,
  p_area_label: i.area, p_lat: i.coords?.lat ?? null, p_lng: i.coords?.lng ?? null, p_is_donor: i.is_donor, p_radius: i.radius });
export async function updateProfile(patch: Partial<Pick<Me, "name" | "gender" | "availability" | "is_donor" | "preferred_radius_km" | "notify_email" | "notify_push" | "area_label" | "phone">>) {
  const { error } = await sb().from("profiles").update(patch).eq("id", await uid()); if (error) throw new Error(error.message);
}
export const setMyArea = (label: string, c: { lat: number; lng: number }) => rpc("set_my_area", { p_label: label, p_lat: c.lat, p_lng: c.lng });
export async function getDonations() {
  const { data, error } = await sb().from("donation_history").select("id,donation_date,source").order("donation_date", { ascending: false });
  if (error) throw new Error(error.message); return data as { id: string; donation_date: string; source: "self_reported" | "facility_confirmed" }[];
}
export const addDonation = (date: string) => rpc("add_self_reported_donation", { p_date: date });

// ---------- phone verification (runs when a donor accepts a request) ----------
async function post(url: string, body?: unknown) {
  const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
  const j = await r.json().catch(() => ({})); if (!r.ok) throw Object.assign(new Error(j.error ?? "Request failed"), { code: j.code }); return j;
}
export const startPhoneVerification = () => post("/api/phone/start");
export const verifyPhone = (code: string) => post("/api/phone/verify", { code });
export const deleteAccount = (confirm: string) => post("/api/account/delete", { confirm });
export const contactDonor = (responseId: string) => post(`/api/contact/${responseId}`);

// ---------- facilities ----------
export type Facility = { id: string; name: string; facility_type: string; address: string; city: string; state: string; status: string };
export async function searchFacilities(q: string) {
  const term = q.trim().replace(/[%,()]/g, "");
  if (term.length < 2) return [] as Facility[];
  const { data, error } = await sb().from("facilities").select("id,name,facility_type,address,city,state,status").eq("status", "verified")
    .or(`name.ilike.%${term}%,city.ilike.%${term}%`).limit(20);
  if (error) throw new Error(error.message); return data as Facility[];
}
export async function listComponents() {
  const { data, error } = await sb().from("blood_components").select("code,label").eq("active", true); if (error) throw new Error(error.message);
  return data as { code: string; label: string }[];
}

// ---------- requests ----------
export type Feed = { id: string; blood_group: BloodGroup; units_required: number; units_fulfilled: number; component: string | null; facility_name: string | null; facility_city: string | null;
  needed_at: string; state: string; verification: "facility_confirmed" | "unconfirmed"; is_urgent_verified: boolean; additional_information: string | null; distance_km: number | null;
  is_mine: boolean; is_facility: boolean; my_response: string | null; my_response_id: string | null; expires_at: string; needs_renewal: boolean };
export const requestFeed = (id?: string) => rpc<Feed[]>("request_feed", { p_id: id ?? null });
export type NewRequest = { facility: string; bg: BloodGroup; units: number; component: string; needed: string; phone: string; relationship: string; patient: string; notes: string; allowCompatible: boolean };
export const createRequest = (i: NewRequest) => rpc<string>("create_request", { p_facility: i.facility, p_blood_group: i.bg, p_units: i.units, p_component: i.component,
  p_needed_at: new Date(i.needed).toISOString(), p_requester_phone: `+91${i.phone}`, p_relationship: i.relationship, p_patient_name: i.patient, p_notes: i.notes, p_allow_compatible: i.allowCompatible });
export const respondToRequest = (id: string) => rpc("respond_to_request", { p_request: id });
export const withdrawResponse = (id: string) => rpc("withdraw_response", { p_response: id });
export type DonorResponse = { response_id: string; donor_first_name: string; blood_group: BloodGroup; blood_group_verified: boolean; distance_km: number | null; availability: string; status: string; created_at: string };
export const responsesFor = (requestId: string) => rpc<DonorResponse[]>("request_responses_for", { p_request: requestId });
export const selectDonor = (id: string) => rpc("select_donor", { p_response: id });
export const rejectResponse = (id: string) => rpc("reject_response", { p_response: id });
export const cancelRequest = (id: string, reason: string) => rpc("cancel_request", { p_request: id, p_reason: reason });
export const markFulfilled = (id: string) => rpc("mark_fulfilled", { p_request: id });
export const extendRequest = (id: string, to: string) => rpc("extend_request", { p_request: id, p_new_needed_at: new Date(to).toISOString() });
export const confirmRequest = (id: string) => rpc("confirm_request", { p_request: id });
export const confirmDonation = (id: string) => rpc("confirm_donation", { p_response: id });
export const reportRequest = (id: string, reason: string, details: string) => rpc("report_request", { p_request: id, p_reason: reason, p_details: details });

// ---------- questionnaire (private) ----------
export type Question = { id: string; label: string; type: "yes_no" | "text"; details_if_yes?: boolean };
export type QState = { template: { id: string; title: string; questions: Question[]; medically_reviewed: boolean }; answers: Record<string, { v: string; d?: string }> | null; submitted_at: string | null } | null;
export const getQuestionnaire = () => rpc<QState>("my_questionnaire");
export const submitQuestionnaire = (answers: Record<string, unknown>) => rpc("submit_questionnaire", { p_answers: answers });

// ---------- notifications ----------
export type Notif = { id: string; kind: string; title: string; body: string | null; request_id: string | null; read_at: string | null; created_at: string };
export async function getNotifications() {
  const { data, error } = await sb().from("notifications").select("id,kind,title,body,request_id,read_at,created_at").order("created_at", { ascending: false }).limit(50);
  if (error) throw new Error(error.message); return data as Notif[];
}
export const markNotificationsRead = (ids: string[] | null) => rpc("mark_notifications_read", { p_ids: ids });
export async function unreadCount() {
  const { count } = await sb().from("notifications").select("id", { count: "exact", head: true }).is("read_at", null); return count ?? 0;
}
export const signOut = () => sb().auth.signOut();

// ---------- access (which staff tools to show; the DB still enforces everything) ----------
export async function getMyAccess() {
  const [roles, fac] = await Promise.all([
    sb().from("user_roles").select("role").eq("user_id", await uid()),
    sb().from("facility_staff").select("facility_id,staff_role,facilities(id,name,city,state,status,rejection_reason,suspended_reason)").eq("user_id", await uid()),
  ]);
  type F = { id: string; name: string; city: string; state: string; status: string; rejection_reason: string | null; suspended_reason: string | null };
  return { roles: (roles.data ?? []).map((r) => r.role as string),
    facilities: ((fac.data ?? []) as any[]).map((r) => ({ ...(r.facilities as F), staff_role: r.staff_role as string })) };
}
// ---------- facilities (staff) ----------
export type NewFacility = { name: string; type: string; address: string; city: string; state: string; pincode: string; phone: string; email: string; lat: number; lng: number };
export const registerFacility = (f: NewFacility) => rpc<string>("register_facility", { p_name: f.name, p_type: f.type, p_address: f.address, p_city: f.city, p_state: f.state, p_pincode: f.pincode,
  p_phone: f.phone ? `+91${f.phone}` : null, p_email: f.email || null, p_lat: f.lat, p_lng: f.lng });
export async function uploadFacilityDoc(facilityId: string, docType: string, file: File) {
  if (file.size > 5 * 1024 * 1024) throw new Error("File must be 5 MB or smaller.");
  if (!["application/pdf", "image/jpeg", "image/png"].includes(file.type)) throw new Error("Upload a PDF, JPG or PNG.");
  const path = `${facilityId}/${crypto.randomUUID()}-${file.name.replace(/[^\w.-]/g, "_").slice(-60)}`;
  const up = await sb().storage.from("facility-docs").upload(path, file, { contentType: file.type });
  if (up.error) throw new Error(up.error.message);
  await rpc("register_facility_document", { p_facility: facilityId, p_doc_type: docType, p_path: path });
}
export const facilityStaffList = (id: string) => rpc<{ user_id: string; first_name: string; staff_role: string; is_me: boolean }[]>("facility_staff_list", { p_facility: id });
export const addFacilityStaff = (id: string, email: string) => rpc("add_facility_staff", { p_facility: id, p_email: email });
export const removeFacilityStaff = (id: string, user: string) => rpc("remove_facility_staff", { p_facility: id, p_user: user });
// ---------- verification officer ----------
export async function facilitiesForReview(status: string) {
  const { data, error } = await sb().from("facilities").select("id,name,facility_type,address,city,state,pincode,status,created_at").eq("status", status).order("created_at");
  if (error) throw new Error(error.message); return data as (Facility & { pincode: string | null; created_at: string })[];
}
export const facilityPrivate = (id: string) => rpc<{ contact_phone: string | null; contact_email: string | null; rejection_reason: string | null; suspended_reason: string | null }>("facility_private", { p_id: id });
export async function facilityDocs(id: string) {
  const { data, error } = await sb().from("facility_documents").select("id,doc_type,storage_path,created_at").eq("facility_id", id);
  if (error) throw new Error(error.message);
  return Promise.all((data ?? []).map(async (d) => ({ ...d, url: (await sb().storage.from("facility-docs").createSignedUrl(d.storage_path, 300)).data?.signedUrl ?? null })));
}
export const reviewFacility = (id: string, action: "approve" | "reject" | "suspend" | "restore", reason: string) => rpc("review_facility", { p_id: id, p_action: action, p_reason: reason });
// ---------- moderation ----------
export type QueueItem = { report_id: string; request_id: string; reason: string; details: string | null; reported_at: string; distinct_reporters: number; priority: boolean; blood_group: BloodGroup; units: number; facility_name: string; request_state: string; confirmed: boolean };
export const moderationQueue = () => rpc<QueueItem[]>("moderation_queue");
export const moderateReport = (id: string, action: "resolve" | "dismiss" | "cancel_request", reason: string) => rpc("moderate_report", { p_report: id, p_action: action, p_reason: reason });
// ---------- admin ----------
export const adminFindUser = (email: string, reason: string) => rpc<{ user_id: string; name: string; donor_code: string; suspended: boolean; roles: string | null }[]>("admin_find_user", { p_email: email, p_reason: reason });
export const setUserRole = (u: string, role: string, grant: boolean, reason: string) => rpc("set_user_role", { p_user: u, p_role: role, p_grant: grant, p_reason: reason });
export const setUserSuspended = (u: string, s: boolean, reason: string) => rpc("set_user_suspended", { p_user: u, p_suspend: s, p_reason: reason });
export async function auditLogs(limit = 100) {
  const { data, error } = await sb().from("audit_logs").select("id,actor_roles,action,entity_type,entity_id,reason,created_at").order("id", { ascending: false }).limit(limit);
  if (error) throw new Error(error.message); return data as { id: number; actor_roles: string | null; action: string; entity_type: string; entity_id: string | null; reason: string | null; created_at: string }[];
}
export async function appConfig() { const { data, error } = await sb().from("app_config").select("key,value,description").order("key"); if (error) throw new Error(error.message); return data as { key: string; value: unknown; description: string | null }[]; }
export const setAppConfig = (key: string, value: unknown, reason: string) => rpc("set_app_config", { p_key: key, p_value: value, p_reason: reason });
// ---------- push ----------
export const savePushSubscription = (s: PushSubscriptionJSON) => rpc("save_push_subscription", { p_endpoint: s.endpoint, p_p256dh: s.keys?.p256dh, p_auth: s.keys?.auth });
