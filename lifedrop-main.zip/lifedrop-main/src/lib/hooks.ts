"use client";
import { useCallback, useEffect, useState } from "react";
export function useAsync<T>(fn: () => Promise<T>, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const run = useCallback(() => { setLoading(true); setError(""); fn().then(setData).catch((e) => setError(e?.message ?? "Something went wrong")).finally(() => setLoading(false)); }, deps);
  useEffect(run, [run]);
  return { data, error, loading, reload: run };
}
export const toast = (m: string) => window.dispatchEvent(new CustomEvent("ld-toast", { detail: m }));
export const locate = () => new Promise<{ lat: number; lng: number }>((res, rej) =>
  navigator.geolocation.getCurrentPosition((p) => res({ lat: p.coords.latitude, lng: p.coords.longitude }), () => rej(new Error("Location unavailable. Allow access or use your saved location."))));
