import "server-only";
// Provider abstractions. Each adapter either really delivers or reports "not_configured": nothing pretends to work.
export type SendResult = { ok: true } | { ok: false; reason: "not_configured" | "failed"; detail?: string };

export interface SmsProvider { send(toE164: string, text: string): Promise<SendResult> }
export interface TelephonyProvider {
  // Connect two parties through a masked number. Neither real number is returned to either party.
  connectMasked(callerE164: string, calleeE164: string, ref: string): Promise<SendResult & { providerRef?: string }>;
}
export interface DeliveryProvider { send(userId: string, title: string, body: string): Promise<SendResult> }

const notConfigured: SendResult = { ok: false, reason: "not_configured" };
// Production: add adapters (e.g. an India-compliant SMS/DLT gateway, a call-masking service) and switch on the env vars.
export const sms = (): SmsProvider => ({ send: async () => notConfigured });
export const telephony = (): TelephonyProvider => ({ connectMasked: async () => notConfigured });

import { supabaseAdmin } from "@/lib/supabase/admin";

// Email via Resend (EMAIL_PROVIDER=resend, RESEND_API_KEY, EMAIL_FROM on a domain you have verified with Resend).
export const emailDelivery = (): DeliveryProvider => process.env.EMAIL_PROVIDER !== "resend" || !process.env.RESEND_API_KEY || !process.env.EMAIL_FROM
  ? { send: async () => notConfigured }
  : { send: async (userId, title, body) => {
      const { data } = await supabaseAdmin().auth.admin.getUserById(userId);
      const to = data?.user?.email; if (!to) return { ok: false, reason: "failed", detail: "no email" };
      const r = await fetch("https://api.resend.com/emails", { method: "POST", headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, "Content-Type": "application/json" },
        body: JSON.stringify({ from: process.env.EMAIL_FROM, to, subject: title, text: `${body}\n\nOpen LifeDrop to respond. Final donor eligibility is determined by the blood bank/facility.` }) });
      return r.ok ? { ok: true } : { ok: false, reason: "failed", detail: `resend ${r.status}` };
    } };

// Web Push (PUSH_PROVIDER=webpush, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY, VAPID_SUBJECT=mailto:you@domain). Generate keys with `npx web-push generate-vapid-keys`.
export const pushDelivery = (): DeliveryProvider => process.env.PUSH_PROVIDER !== "webpush" || !process.env.VAPID_PUBLIC_KEY || !process.env.VAPID_PRIVATE_KEY
  ? { send: async () => notConfigured }
  : { send: async (userId, title, body) => {
      const wp = (await import("web-push")).default;
      wp.setVapidDetails(process.env.VAPID_SUBJECT ?? "mailto:admin@example.com", process.env.VAPID_PUBLIC_KEY!, process.env.VAPID_PRIVATE_KEY!);
      const admin = supabaseAdmin();
      const { data: subs } = await admin.from("push_subscriptions").select("id,endpoint,p256dh,auth").eq("user_id", userId);
      if (!subs?.length) return { ok: false, reason: "failed", detail: "no subscription" };
      let any = false;
      for (const s of subs) {
        try { await wp.sendNotification({ endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } }, JSON.stringify({ title, body })); any = true; }
        catch (e: any) { if (e?.statusCode === 404 || e?.statusCode === 410) await admin.from("push_subscriptions").delete().eq("id", s.id); }
      }
      return any ? { ok: true } : { ok: false, reason: "failed", detail: "all subscriptions failed" };
    } };
