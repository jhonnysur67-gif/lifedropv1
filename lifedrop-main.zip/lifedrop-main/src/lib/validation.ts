// Pure validators shared by UI and API routes. Mirrored by DB constraints (the DB is authoritative).
export const INDIAN_MOBILE = /^[6-9]\d{9}$/;
export const toE164 = (digits: string) => `+91${digits}`;
export const isIndianMobile = (digits: string) => INDIAN_MOBILE.test(digits);
export const looksLikePhoneInText = (s: string) => /(\+?91)?[ -]?[6-9]([ -]?\d){9}/.test(s);
export const isSixDigitCode = (s: string) => /^\d{6}$/.test(s);
export const isUuid = (s: string) => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s);
