import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";

const AUTH_PAGES = ["/login", "/signup"];
const isPublic = (p: string) =>
  p === "/" || AUTH_PAGES.includes(p) || p.startsWith("/api/cron/");

export async function middleware(req: NextRequest) {
  let res = NextResponse.next({ request: req });

  const sb = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll: () => req.cookies.getAll(),

        setAll: (
          list: {
            name: string;
            value: string;
            options?: Record<string, unknown>;
          }[]
        ) => {
          list.forEach(({ name, value }) => req.cookies.set(name, value));

          res = NextResponse.next({ request: req });

          list.forEach(({ name, value, options }) =>
            res.cookies.set(name, value, options)
          );
        },
      },
    }
  );

  const {
    data: { user },
  } = await sb.auth.getUser();

  const path = req.nextUrl.pathname;
  const go = (to: string) =>
    NextResponse.redirect(new URL(to, req.url));
  const api = path.startsWith("/api/");

  if (!user)
    return isPublic(path)
      ? res
      : api
        ? NextResponse.json({ error: "Not signed in" }, { status: 401 })
        : go("/login");

  if (api || path.startsWith("/api/cron/")) return res;

  const { data: p } = await sb
    .from("profiles")
    .select("onboarding_completed")
    .eq("id", user.id)
    .maybeSingle();

  const done = !!p?.onboarding_completed;

  if (!done && path !== "/onboarding") return go("/onboarding");

  if (
    done &&
    (path === "/onboarding" || AUTH_PAGES.includes(path))
  )
    return go("/home");

  return res;
}

export const config = {
  matcher: ["/((?!_next|favicon.ico|.*\\..*).*)"],
};
