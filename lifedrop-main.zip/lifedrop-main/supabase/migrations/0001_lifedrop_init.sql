-- LifeDrop V1 schema. Run in Supabase SQL editor or via `supabase db push`.
create extension if not exists postgis;

create type blood_group_t as enum ('A+','A-','B+','B-','O+','O-','AB+','AB-');
create type availability_t as enum ('available_now','available_later','not_available');
create type urgency_t as enum ('urgent','high','normal');
create type request_status_t as enum ('active','fulfilled','expired','cancelled');
create type response_status_t as enum ('pending','accepted','declined','completed');

create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text,
  age int check (age between 18 and 65),
  gender text,
  blood_group blood_group_t,
  is_donor boolean not null default false,          -- willingness only, not a role
  availability availability_t not null default 'not_available',
  last_donation_date date,
  preferred_radius_km int check (preferred_radius_km in (5,10,25)) default 10,
  location geography(Point,4326),                   -- private, never returned to other users
  city text,                                        -- public, coarse label (e.g. Puttur)
  donor_code text unique default 'LD' || lpad((floor(random()*9000)+1000)::int::text, 4, '0'),
  onboarding_completed boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index profiles_location_gix on profiles using gist (location);

create table blood_requests (
  id uuid primary key default gen_random_uuid(),
  requester_id uuid not null references profiles(id) on delete cascade,
  blood_group blood_group_t not null,
  units_required int not null check (units_required between 1 and 10),
  hospital_name text not null,
  location geography(Point,4326) not null,          -- hospital location (public by design)
  urgency urgency_t not null default 'normal',
  needed_at timestamptz not null,
  additional_information text,
  status request_status_t not null default 'active',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index blood_requests_location_gix on blood_requests using gist (location);
create index blood_requests_status_needed_idx on blood_requests (status, needed_at);
create index blood_requests_requester_idx on blood_requests (requester_id);

create table request_responses (
  id uuid primary key default gen_random_uuid(),
  request_id uuid not null references blood_requests(id) on delete cascade,
  donor_id uuid not null references profiles(id) on delete cascade,
  status response_status_t not null default 'pending',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (request_id, donor_id)
);
create index request_responses_donor_idx on request_responses (donor_id);

create table donation_history (
  id uuid primary key default gen_random_uuid(),
  donor_id uuid not null references profiles(id) on delete cascade,
  donation_date date not null,
  created_at timestamptz not null default now()
);
create index donation_history_donor_idx on donation_history (donor_id, donation_date desc);

-- updated_at trigger
create function set_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;
create trigger t_profiles before update on profiles for each row execute function set_updated_at();
create trigger t_requests before update on blood_requests for each row execute function set_updated_at();
create trigger t_responses before update on request_responses for each row execute function set_updated_at();

-- auto-create empty profile row on signup so onboarding state persists
create function handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin insert into profiles (id) values (new.id) on conflict do nothing; return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

-- RLS
alter table profiles enable row level security;
alter table blood_requests enable row level security;
alter table request_responses enable row level security;
alter table donation_history enable row level security;

create policy "own profile read" on profiles for select using (auth.uid() = id);
create policy "own profile update" on profiles for update using (auth.uid() = id) with check (auth.uid() = id);
create policy "own profile insert" on profiles for insert with check (auth.uid() = id);

-- Requests: any signed-in user can read active ones; only requester writes.
create policy "read requests" on blood_requests for select to authenticated
  using (status = 'active' and needed_at > now() or requester_id = auth.uid());
create policy "create request" on blood_requests for insert to authenticated
  with check (requester_id = auth.uid());
create policy "update own request" on blood_requests for update to authenticated
  using (requester_id = auth.uid()) with check (requester_id = auth.uid());

-- Responses: donor manages own; requester can see responses to their requests.
create policy "donor manages response" on request_responses for all to authenticated
  using (donor_id = auth.uid()) with check (donor_id = auth.uid());
create policy "requester sees responses" on request_responses for select to authenticated
  using (exists (select 1 from blood_requests r where r.id = request_id and r.requester_id = auth.uid()));

create policy "own donation history" on donation_history for all to authenticated
  using (donor_id = auth.uid()) with check (donor_id = auth.uid());

-- Privacy-safe donor discovery: returns only anonymous code, blood group,
-- availability, city and a distance rounded to 0.1 km. Never exact coordinates,
-- name or phone. Runs as definer so it can read other profiles' private location.
create function find_donors(p_blood_group blood_group_t, p_radius_km int, p_only_available boolean default true)
returns table (donor_code text, blood_group blood_group_t, availability availability_t, city text, distance_km numeric)
language sql stable security definer set search_path = public as $$
  select d.donor_code, d.blood_group, d.availability, d.city,
         round((st_distance(d.location, me.location) / 1000)::numeric, 1)
  from profiles d, profiles me
  where me.id = auth.uid() and me.location is not null
    and d.id <> me.id and d.is_donor and d.onboarding_completed
    and d.blood_group = p_blood_group
    and (not p_only_available or d.availability = 'available_now')
    and st_dwithin(d.location, me.location, p_radius_km * 1000)
  order by 5 limit 50;
$$;
revoke all on function find_donors from public;
grant execute on function find_donors to authenticated;

-- Expire stale requests (schedule with pg_cron or call from an edge function).
create function expire_requests() returns void language sql security definer set search_path = public as $$
  update blood_requests set status = 'expired' where status = 'active' and needed_at < now();
$$;
