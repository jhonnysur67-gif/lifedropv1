-- Age: accounts 13+, donor age rule applies only to donors.
alter table profiles drop constraint if exists profiles_age_check;
alter table profiles add constraint profiles_age_check check (age is null or age between 13 and 120);
alter table profiles add constraint profiles_donor_age_check check (not is_donor or age is null or age between 18 and 65);

-- Hide request coordinates from direct table reads; distance is served by request_feed().
revoke select on blood_requests from authenticated;
grant select (id,requester_id,blood_group,units_required,hospital_name,urgency,needed_at,additional_information,status,created_at,updated_at) on blood_requests to authenticated;

create function request_feed(p_id uuid default null)
returns table (id uuid, blood_group blood_group_t, units_required int, hospital_name text, urgency urgency_t, needed_at timestamptz,
  additional_information text, status text, distance_km numeric, is_mine boolean, has_responded boolean)
language sql stable security definer set search_path = public as $$
  select r.id, r.blood_group, r.units_required, r.hospital_name, r.urgency, r.needed_at, r.additional_information,
    case when r.status = 'active' and r.needed_at < now() then 'expired' else r.status::text end,
    round((st_distance(r.location, (select p.location from profiles p where p.id = auth.uid())) / 1000)::numeric, 1),
    r.requester_id = auth.uid(),
    exists (select 1 from request_responses x where x.request_id = r.id and x.donor_id = auth.uid())
  from blood_requests r
  where auth.uid() is not null and (p_id is null or r.id = p_id)
    and ((r.status = 'active' and r.needed_at > now()) or r.requester_id = auth.uid())
  order by r.needed_at;
$$;
revoke all on function request_feed from public; grant execute on function request_feed to authenticated;

create function create_request(p_blood_group blood_group_t, p_units int, p_hospital text, p_urgency urgency_t,
  p_needed_at timestamptz, p_info text, p_lat double precision, p_lng double precision)
returns uuid language plpgsql as $$
declare loc geography; rid uuid;
begin
  if p_lat is not null then loc := st_setsrid(st_makepoint(p_lng, p_lat), 4326)::geography;
  else select location into loc from profiles where id = auth.uid(); end if;
  if loc is null then raise exception 'Location required: allow location or set one in your profile.'; end if;
  insert into blood_requests (requester_id, blood_group, units_required, hospital_name, location, urgency, needed_at, additional_information)
  values (auth.uid(), p_blood_group, p_units, p_hospital, loc, p_urgency, p_needed_at, nullif(p_info, ''))
  returning blood_requests.id into rid;
  return rid;
end $$;
grant execute on function create_request to authenticated;

create table reports (
  id uuid primary key default gen_random_uuid(),
  request_id uuid not null references blood_requests(id) on delete cascade,
  reporter_id uuid not null default auth.uid() references profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (request_id, reporter_id)
);
alter table reports enable row level security;
create policy "report insert" on reports for insert to authenticated with check (reporter_id = auth.uid());
