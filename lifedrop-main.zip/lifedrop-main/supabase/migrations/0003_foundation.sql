-- LifeDrop 0003: production foundation (roles, facilities, audit, config, privacy-safe schema, RLS).
-- NOT executed in the authoring environment (no Postgres available). Apply first on a Supabase branch / local
-- `supabase db reset`, run supabase/tests/workflow.sql, and only then promote.
-- Legacy prototype rows are preserved: old free-text requests are closed (not deleted) and flagged is_legacy.

create extension if not exists pgcrypto;

-- ============ enums ============
create type platform_role_t  as enum ('verification_officer','moderator','admin');   -- 'User' is implicit; facility staff via facility_staff
create type facility_status_t as enum ('pending','verified','rejected','suspended');
create type request_state_t  as enum ('draft','pending_verification','active','partially_fulfilled','fulfilled','expired','cancelled');
create type response_state_t as enum ('accepted','selected','withdrawn','declined','completed');
create type report_status_t  as enum ('open','resolved','dismissed');

-- ============ configuration (operational rules are data, not code) ============
-- Values below marked [DEFAULT] are operational defaults NOT yet approved by you; edit in app_config.
create table app_config (
  key text primary key, value jsonb not null, description text,
  updated_by uuid, updated_at timestamptz not null default now()
);
insert into app_config (key, value, description) values
 ('unconfirmed_request', '{"max_radius_km":5,"ttl_minutes":120,"max_open_per_account":1}', 'Approved rules for unconfirmed requests'),
 ('radius_escalation',   '{"steps_km":[5,10,25,50],"step_interval_minutes":30,"escalate_admin_after_step":2}', '[DEFAULT] radius steps/timing; last step is the hard maximum'),
 ('quiet_hours',         '{"timezone":"Asia/Kolkata","start":"22:00","end":"07:00"}', 'Approved: 10 PM to 7 AM'),
 ('urgent_window_hours', '24', '[DEFAULT] facility-confirmed request needed within this many hours counts as verified-urgent'),
 ('request_limits',      '{"max_requests_per_24h":3,"max_extensions":3,"max_days_ahead":30,"still_needed_prompt_minutes":60}', '[DEFAULT] abuse limits'),
 ('reports',             '{"max_reports_per_day":10,"priority_after_reporters":2}', '[DEFAULT] report abuse control; reports never auto-hide a request'),
 ('matching',            '{"max_donors_per_step":200}', '[DEFAULT]'),
 ('location',            '{"grid_degrees":0.01}', 'Approx-location snap grid (~1 km). Exact GPS is never stored'),
 ('eligibility_gates',   '{"min_account_age":13,"min_donor_age":18,"require_reviewed_questionnaire":true}', '[NEEDS LEGAL/MEDICAL REVIEW] min_donor_age is a legal-majority gate, not medical eligibility');

create function cfg(p_key text) returns jsonb language sql stable set search_path = public as
$$ select value from app_config where key = p_key $$;

-- ============ roles & audit ============
create table user_roles (
  user_id uuid not null references profiles(id) on delete cascade,
  role platform_role_t not null, granted_by uuid, created_at timestamptz not null default now(),
  primary key (user_id, role)
);
create function has_role(r platform_role_t) returns boolean language sql stable security definer set search_path = public as
$$ select exists (select 1 from user_roles where user_id = auth.uid() and role = r) $$;

create table audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid, actor_roles text, action text not null, entity_type text not null, entity_id text,
  reason text, metadata jsonb not null default '{}', created_at timestamptz not null default now()
);
create index audit_logs_entity_idx on audit_logs (entity_type, entity_id);
create index audit_logs_created_idx on audit_logs (created_at desc);

create function write_audit(p_action text, p_entity_type text, p_entity_id text, p_reason text default null, p_metadata jsonb default '{}')
returns void language sql security definer set search_path = public as $$
  insert into audit_logs (actor_id, actor_roles, action, entity_type, entity_id, reason, metadata)
  values (auth.uid(), (select string_agg(role::text, ',') from user_roles where user_id = auth.uid()),
          p_action, p_entity_type, p_entity_id, p_reason, coalesce(p_metadata, '{}'))
$$;
revoke all on function write_audit from public, anon, authenticated;  -- callable only from other definer functions

create function audit_immutable() returns trigger language plpgsql as $$
begin
  if current_setting('app.anonymizing', true) = 'on' and tg_op = 'UPDATE' then return new; end if;
  raise exception 'audit_logs is append-only';
end $$;
create trigger t_audit_immutable before update or delete on audit_logs for each row execute function audit_immutable();

-- ============ profiles: required fields, privacy-safe location, robust donor number ============
drop function if exists find_donors(blood_group_t, int, boolean);     -- donor directory removed: scraping surface
drop function if exists request_feed(uuid);
drop function if exists create_request(blood_group_t, int, text, urgency_t, timestamptz, text, double precision, double precision);
drop function if exists expire_requests();

alter table profiles
  add column date_of_birth date,
  add column phone text,
  add column phone_verified_at timestamptz,
  add column area_point geography(Point,4326),          -- snapped to ~1 km grid; exact GPS never stored
  add column area_label text,
  add column blood_group_verified_at timestamptz,
  add column blood_group_verified_by uuid,
  add column notify_email boolean not null default true,
  add column notify_push boolean not null default true,
  add column suspended_at timestamptz,
  add column deleted_at timestamptz;

-- migrate legacy exact location -> snapped approximate point, then drop the exact column
update profiles set area_point = st_snaptogrid(location::geometry, 0.01)::geography where location is not null;
update profiles set area_label = city where area_label is null;
drop index if exists profiles_location_gix;
alter table profiles drop column location;
create index profiles_area_gix on profiles using gist (area_point);

-- age is legacy (DOB replaces it); remove the hardcoded 18-65 donor rule (an eligibility decision)
alter table profiles drop constraint if exists profiles_donor_age_check;
alter table profiles drop constraint if exists profiles_age_check;
-- profiles that lack the now-required fields must re-complete onboarding
update profiles set onboarding_completed = false where date_of_birth is null or phone is null;
alter table profiles add constraint profiles_phone_fmt check (phone is null or phone ~ '^\+91[6-9][0-9]{9}$');

create function gen_donor_code() returns text language plpgsql volatile as $$
declare alphabet constant text := '23456789ABCDEFGHJKMNPQRSTVWXYZ';  -- 30 symbols, no 0/O/1/I/L
        b bytea; c text; i int;
begin
  loop
    b := gen_random_bytes(10); c := 'LD-';
    for i in 0..9 loop
      c := c || substr(alphabet, (get_byte(b, i) % 30) + 1, 1);
      if i = 4 then c := c || '-'; end if;
    end loop;
    exit when not exists (select 1 from profiles where donor_code = c);
  end loop;
  return c;   -- ~5.9e14 space, server-generated; UNIQUE constraint is the final backstop
end $$;
update profiles set donor_code = gen_donor_code();     -- old LD#### codes were a 9,000-value space
alter table profiles alter column donor_code set default gen_donor_code();
alter table profiles alter column donor_code set not null;

create function profiles_guard() returns trigger language plpgsql as $$
begin
  if new.phone is distinct from old.phone then new.phone_verified_at := null; end if;
  if new.blood_group is distinct from old.blood_group then new.blood_group_verified_at := null; new.blood_group_verified_by := null; end if;
  return new;
end $$;
create trigger t_profiles_guard before update on profiles for each row execute function profiles_guard();

-- clients may no longer insert profiles or edit privileged columns
drop policy if exists "own profile insert" on profiles;
revoke all on profiles from anon, authenticated;
grant select on profiles to authenticated;
grant update (name, gender, date_of_birth, blood_group, phone, area_label, is_donor, availability, preferred_radius_km, notify_email, notify_push) on profiles to authenticated;

-- ============ facilities (source-agnostic so ABDM HFR can replace 'manual' later) ============
create table facilities (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(trim(name)) >= 3),
  facility_type text not null check (facility_type in ('hospital','blood_bank','clinic','other')),
  address text not null, city text not null, state text not null, pincode text,
  contact_phone text, contact_email text,
  location geography(Point,4326) not null,
  status facility_status_t not null default 'pending',
  rejection_reason text, suspended_reason text,
  verified_by uuid, verified_at timestamptz,
  source text not null default 'manual',
  external_registry_id text,
  created_by uuid, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create unique index facilities_external_uq on facilities (source, external_registry_id) where external_registry_id is not null;
create index facilities_location_gix on facilities using gist (location);
create index facilities_status_idx on facilities (status);
create trigger t_facilities before update on facilities for each row execute function set_updated_at();

create table facility_staff (
  facility_id uuid not null references facilities(id) on delete cascade,
  user_id uuid not null references profiles(id) on delete cascade,
  staff_role text not null default 'staff' check (staff_role in ('staff','manager')),
  added_by uuid, created_at timestamptz not null default now(),
  primary key (facility_id, user_id)
);
create index facility_staff_user_idx on facility_staff (user_id);

create table facility_documents (
  id uuid primary key default gen_random_uuid(),
  facility_id uuid not null references facilities(id) on delete cascade,
  doc_type text not null, storage_path text not null unique,
  uploaded_by uuid, created_at timestamptz not null default now()
);

create function is_facility_member(p_facility uuid) returns boolean language sql stable security definer set search_path = public as
$$ select exists (select 1 from facility_staff where facility_id = p_facility and user_id = auth.uid()) $$;
create function is_facility_staff(p_facility uuid) returns boolean language sql stable security definer set search_path = public as
$$ select exists (select 1 from facility_staff s join facilities f on f.id = s.facility_id
                  where s.facility_id = p_facility and s.user_id = auth.uid() and f.status = 'verified') $$;
create function is_facility_manager(p_facility uuid) returns boolean language sql stable security definer set search_path = public as
$$ select exists (select 1 from facility_staff s join facilities f on f.id = s.facility_id
                  where s.facility_id = p_facility and s.user_id = auth.uid() and s.staff_role = 'manager' and f.status = 'verified') $$;

-- ============ reference data: components & compatibility (medical content => reviewable, never hardcoded) ============
create table blood_components (
  code text primary key, label text not null, active boolean not null default true,
  needs_review boolean not null default true
);
insert into blood_components (code, label) values
 ('whole_blood','Whole blood'), ('red_cells','Red cell concentrate'), ('platelets','Platelets'), ('plasma','Plasma');

-- Empty until a medical professional supplies the reviewed chart. Exact-group matching always works without it.
create table blood_compatibility (
  recipient blood_group_t not null, donor blood_group_t not null,
  reviewed_by text not null, reviewed_at date not null,
  primary key (recipient, donor)
);

create function donor_matches(p_donor blood_group_t, p_recipient blood_group_t, p_allow boolean)
returns boolean language sql stable set search_path = public as $$
  select p_donor = p_recipient
      or (p_allow and exists (select 1 from blood_compatibility c where c.recipient = p_recipient and c.donor = p_donor))
$$;

-- ============ blood_requests: new lifecycle, verified facility, private contact fields ============
drop policy if exists "read requests" on blood_requests;
drop policy if exists "create request" on blood_requests;
drop policy if exists "update own request" on blood_requests;

alter table blood_requests add column is_legacy boolean not null default false;
update blood_requests set is_legacy = true;
alter table blood_requests alter column status drop default;
alter table blood_requests alter column status type request_state_t
  using (case status::text when 'active' then 'cancelled' else status::text end)::request_state_t;  -- legacy free-text requests cannot meet the verified-facility rule
alter table blood_requests alter column status set default 'pending_verification';
alter table blood_requests add column closed_reason text;
update blood_requests set closed_reason = 'legacy_prototype_request' where is_legacy and status = 'cancelled';
alter table blood_requests drop column urgency;   -- urgency is now derived server-side, never requester-set
drop type urgency_t;
drop type request_status_t;

alter table blood_requests
  add column facility_id uuid references facilities(id),
  add column component text references blood_components(code),
  add column relationship_to_patient text,
  add column requester_phone text,               -- private
  add column patient_name text,                  -- private
  add column allow_compatible boolean not null default false,
  add column confirmed_by uuid, add column confirmed_at timestamptz,
  add column expires_at timestamptz,
  add column current_radius_km int not null default 5,
  add column radius_step int not null default 0,
  add column last_expanded_at timestamptz,
  add column escalated_at timestamptz,
  add column units_fulfilled int not null default 0,
  add column extensions_used int not null default 0,
  add column renewal_prompted_at timestamptz;
alter table blood_requests add constraint br_units_fulfilled check (units_fulfilled between 0 and units_required);
alter table blood_requests add constraint br_facility_required check (is_legacy or facility_id is not null);
alter table blood_requests add constraint br_notes_len check (additional_information is null or length(additional_information) <= 500);
alter table blood_requests alter column requester_id drop not null;       -- retained anonymised after account deletion
alter table blood_requests drop constraint blood_requests_requester_id_fkey;
alter table blood_requests add constraint blood_requests_requester_id_fkey foreign key (requester_id) references profiles(id) on delete set null;
create index blood_requests_facility_idx on blood_requests (facility_id, status);
create index blood_requests_open_idx on blood_requests (status, expires_at);

create function request_transition_ok(p_old request_state_t, p_new request_state_t) returns boolean language sql immutable as $$
  select p_old = p_new or (p_old, p_new) in (
    ('draft','pending_verification'), ('draft','active'), ('draft','cancelled'),
    ('pending_verification','active'), ('pending_verification','expired'), ('pending_verification','cancelled'),
    ('active','partially_fulfilled'), ('active','fulfilled'), ('active','expired'), ('active','cancelled'), ('active','pending_verification'),
    ('partially_fulfilled','fulfilled'), ('partially_fulfilled','expired'), ('partially_fulfilled','cancelled'), ('partially_fulfilled','pending_verification'))
$$;
create function blood_requests_guard() returns trigger language plpgsql as $$
begin
  if not request_transition_ok(old.status, new.status) then
    raise exception 'Invalid request state transition % -> %', old.status, new.status;
  end if;
  return new;
end $$;
create trigger t_requests_guard before update of status on blood_requests for each row execute function blood_requests_guard();

-- requests are readable ONLY through definer RPCs (phones/patient data never reach the client)
revoke all on blood_requests from anon, authenticated;

-- ============ responses ============
drop policy if exists "donor manages response" on request_responses;
drop policy if exists "requester sees responses" on request_responses;
alter table request_responses alter column status drop default;
alter table request_responses alter column status type response_state_t
  using (case status::text when 'declined' then 'declined' when 'completed' then 'completed' else 'withdrawn' end)::response_state_t;  -- legacy rows had no phone verification
alter table request_responses alter column status set default 'accepted';
drop type response_status_t;
alter table request_responses add column selected_at timestamptz, add column withdrawn_at timestamptz;
alter table request_responses alter column donor_id drop not null;
alter table request_responses drop constraint request_responses_donor_id_fkey;
alter table request_responses add constraint request_responses_donor_id_fkey foreign key (donor_id) references profiles(id) on delete set null;
revoke all on request_responses from anon, authenticated;
grant select on request_responses to authenticated;
create policy "own responses" on request_responses for select to authenticated using (donor_id = auth.uid());

-- ============ donation history ============
drop policy if exists "own donation history" on donation_history;
alter table donation_history
  add column facility_id uuid references facilities(id), add column request_id uuid references blood_requests(id) on delete set null,
  add column response_id uuid references request_responses(id) on delete set null,
  add column source text not null default 'self_reported' check (source in ('self_reported','facility_confirmed')),
  add column confirmed_by uuid, add column confirmed_at timestamptz;
create unique index donation_confirm_once_uq on donation_history (response_id) where response_id is not null;
alter table donation_history alter column donor_id drop not null;
alter table donation_history drop constraint donation_history_donor_id_fkey;
alter table donation_history add constraint donation_history_donor_id_fkey foreign key (donor_id) references profiles(id) on delete set null;
revoke all on donation_history from anon, authenticated;
grant select (id, donation_date, source) on donation_history to authenticated;
create policy "own donations" on donation_history for select to authenticated using (donor_id = auth.uid());

-- ============ health questionnaire (sensitive, template-driven, reviewable) ============
create table questionnaire_templates (
  id uuid primary key default gen_random_uuid(), version int not null unique, title text not null,
  questions jsonb not null,                       -- [{id,label,type:'yes_no'|'text',details_if_yes:bool}]
  medically_reviewed boolean not null default false, reviewed_by text, reviewed_at date,
  is_active boolean not null default false, created_at timestamptz not null default now()
);
create unique index one_active_template on questionnaire_templates (is_active) where is_active;
-- DRAFT topic list from your brief. Wording is NOT medically reviewed; production use is blocked until medically_reviewed = true.
insert into questionnaire_templates (version, title, questions, is_active) values (1, 'Donor health & safety (DRAFT, unreviewed)', jsonb_build_array(
 jsonb_build_object('id','tobacco','label','Do you use tobacco or smoke?','type','yes_no'),
 jsonb_build_object('id','alcohol_substances','label','Do you use alcohol or other substances?','type','yes_no'),
 jsonb_build_object('id','recent_illness','label','Have you had a recent illness, fever or infection?','type','yes_no','details_if_yes',true),
 jsonb_build_object('id','medications','label','Are you currently taking any medication?','type','yes_no','details_if_yes',true),
 jsonb_build_object('id','chronic','label','Do you have any chronic medical condition?','type','yes_no','details_if_yes',true),
 jsonb_build_object('id','surgery','label','Have you had recent surgery or a medical procedure?','type','yes_no','details_if_yes',true),
 jsonb_build_object('id','tattoo_piercing','label','Have you had a recent tattoo or piercing?','type','yes_no','details_if_yes',true),
 jsonb_build_object('id','pregnancy','label','Where applicable: are you pregnant or recently postpartum?','type','yes_no'),
 jsonb_build_object('id','transfusion_donation','label','Have you recently received a transfusion or donated blood?','type','yes_no','details_if_yes',true),
 jsonb_build_object('id','other_history','label','Any other medical history the blood bank should know?','type','text')), true);

create table donor_health_questionnaires (
  id uuid primary key default gen_random_uuid(),
  donor_id uuid not null references profiles(id) on delete cascade,
  template_id uuid not null references questionnaire_templates(id),
  answers jsonb not null, submitted_at timestamptz not null default now(),
  unique (donor_id, template_id)
);
revoke all on donor_health_questionnaires from anon, authenticated;   -- RPC-only; donor reads own via my_questionnaire()
revoke all on questionnaire_templates from anon, authenticated;
grant select on questionnaire_templates to authenticated;

-- ============ notifications (in-app rows + outbox for email/push) ============
create table notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  kind text not null, title text not null, body text,
  request_id uuid references blood_requests(id) on delete cascade,
  dedupe_key text, read_at timestamptz, created_at timestamptz not null default now()
);
create unique index notifications_dedupe_uq on notifications (user_id, dedupe_key) where dedupe_key is not null;
create index notifications_user_idx on notifications (user_id, created_at desc);
create table notification_deliveries (
  id uuid primary key default gen_random_uuid(),
  notification_id uuid not null references notifications(id) on delete cascade,
  channel text not null check (channel in ('email','push')),
  status text not null default 'pending' check (status in ('pending','sent','failed','suppressed_quiet_hours')),
  attempts int not null default 0, last_error text, sent_at timestamptz, created_at timestamptz not null default now(),
  unique (notification_id, channel)
);
create index deliveries_pending_idx on notification_deliveries (status) where status = 'pending';
create table push_subscriptions (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references profiles(id) on delete cascade,
  endpoint text not null unique, p256dh text not null, auth text not null, created_at timestamptz not null default now()
);

-- ============ reports / moderation ============
alter table reports add column reason text not null default 'other' check (reason in ('fake_request','spam','harassment','wrong_details','other')),
  add column details text check (details is null or length(details) <= 500),
  add column status report_status_t not null default 'open',
  add column resolved_by uuid, add column resolved_at timestamptz, add column resolution text;
alter table reports alter column reporter_id drop not null;
alter table reports drop constraint reports_reporter_id_fkey;
alter table reports add constraint reports_reporter_id_fkey foreign key (reporter_id) references profiles(id) on delete set null;
drop policy if exists "report insert" on reports;
revoke all on reports from anon, authenticated;
create table moderation_actions (
  id uuid primary key default gen_random_uuid(), report_id uuid references reports(id) on delete set null,
  request_id uuid references blood_requests(id) on delete set null, moderator_id uuid,
  action text not null, reason text not null, created_at timestamptz not null default now()
);

-- ============ phone verification, contact sessions, deletion records (server/service-role only) ============
create table phone_verifications (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references profiles(id) on delete cascade,
  phone text not null, code_hash text not null, expires_at timestamptz not null,
  attempts int not null default 0, verified_at timestamptz, created_at timestamptz not null default now()
);
create index phone_verifications_user_idx on phone_verifications (user_id, created_at desc);
create table contact_sessions (
  id uuid primary key default gen_random_uuid(),
  request_id uuid references blood_requests(id) on delete set null,
  response_id uuid references request_responses(id) on delete set null,
  provider text not null, provider_ref text, status text not null default 'requested',
  created_at timestamptz not null default now()
);
create table deletion_records (id uuid primary key default gen_random_uuid(), deleted_at timestamptz not null default now());  -- deliberately unlinked

-- ============ RLS on everything; explicit deny-by-default for client roles ============
alter table app_config enable row level security;       alter table user_roles enable row level security;
alter table audit_logs enable row level security;       alter table facilities enable row level security;
alter table facility_staff enable row level security;   alter table facility_documents enable row level security;
alter table blood_components enable row level security; alter table blood_compatibility enable row level security;
alter table blood_requests enable row level security;   alter table questionnaire_templates enable row level security;
alter table donor_health_questionnaires enable row level security;
alter table notifications enable row level security;    alter table notification_deliveries enable row level security;
alter table push_subscriptions enable row level security; alter table reports enable row level security;
alter table moderation_actions enable row level security; alter table phone_verifications enable row level security;
alter table contact_sessions enable row level security; alter table deletion_records enable row level security;

revoke all on app_config, user_roles, audit_logs, facilities, facility_staff, facility_documents, blood_components, blood_compatibility,
  notifications, notification_deliveries, push_subscriptions, moderation_actions, phone_verifications, contact_sessions, deletion_records
  from anon, authenticated;

grant select on app_config, blood_components, blood_compatibility, user_roles, audit_logs, facility_staff, facility_documents, notifications to authenticated;
grant select (id, name, facility_type, address, city, state, pincode, status, source, external_registry_id, created_at) on facilities to authenticated;

create policy "read config" on app_config for select to authenticated using (true);
create policy "read components" on blood_components for select to authenticated using (true);
create policy "read compat" on blood_compatibility for select to authenticated using (true);
create policy "read templates" on questionnaire_templates for select to authenticated using (is_active);
create policy "own roles" on user_roles for select to authenticated using (user_id = auth.uid() or has_role('admin'));
create policy "admin reads audit" on audit_logs for select to authenticated using (has_role('admin'));
create policy "facility visibility" on facilities for select to authenticated
  using (status = 'verified' or is_facility_member(id) or has_role('verification_officer') or has_role('admin'));
create policy "staff rows" on facility_staff for select to authenticated
  using (user_id = auth.uid() or is_facility_member(facility_id) or has_role('admin'));
create policy "facility docs" on facility_documents for select to authenticated
  using (is_facility_member(facility_id) or has_role('verification_officer') or has_role('admin'));
create policy "own notifications" on notifications for select to authenticated using (user_id = auth.uid());
-- blood_requests, donor_health_questionnaires, reports, deliveries, phone_verifications, contact_sessions: no client policies = no direct access.

-- ============ private storage for facility documents ============
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('facility-docs', 'facility-docs', false, 5242880, array['application/pdf','image/jpeg','image/png'])
on conflict (id) do nothing;
create policy "facility docs upload" on storage.objects for insert to authenticated
  with check (bucket_id = 'facility-docs' and is_facility_member(((storage.foldername(name))[1])::uuid));
create policy "facility docs read" on storage.objects for select to authenticated
  using (bucket_id = 'facility-docs' and (is_facility_member(((storage.foldername(name))[1])::uuid)
         or has_role('verification_officer') or has_role('admin')));
