-- LifeDrop 0004: authoritative server-side workflows. All state changes go through these definer functions
-- (clients have no write access to the underlying tables). NOT executed in the authoring environment.

-- ============ helpers ============
create function in_quiet_hours(p_at timestamptz default now()) returns boolean language plpgsql stable set search_path = public as $$
declare c jsonb := cfg('quiet_hours'); t time := (p_at at time zone (c->>'timezone'))::time;
        s time := (c->>'start')::time; e time := (c->>'end')::time;
begin
  if s > e then return t >= s or t < e; else return t >= s and t < e; end if;
end $$;

-- Urgent-bypass is computed here, never taken from the requester: facility-confirmed AND needed soon.
create function is_urgent_verified(r blood_requests) returns boolean language sql stable set search_path = public as $$
  select r.confirmed_by is not null and r.status in ('active','partially_fulfilled')
     and r.needed_at <= now() + make_interval(hours => coalesce((cfg('urgent_window_hours') #>> '{}')::int, 24))
$$;

create function enqueue_notification(p_user uuid, p_kind text, p_title text, p_body text, p_request uuid, p_dedupe text,
  p_email boolean, p_push boolean, p_urgent boolean) returns void language plpgsql security definer set search_path = public as $$
declare nid uuid; pr profiles; quiet boolean := in_quiet_hours();
begin
  if p_user is null then return; end if;
  select * into pr from profiles where id = p_user and deleted_at is null;
  if not found then return; end if;
  insert into notifications (user_id, kind, title, body, request_id, dedupe_key)
  values (p_user, p_kind, p_title, p_body, p_request, p_dedupe)
  on conflict (user_id, dedupe_key) where dedupe_key is not null do nothing
  returning id into nid;
  if nid is null then return; end if;
  if p_email and pr.notify_email then
    insert into notification_deliveries (notification_id, channel, status)
    values (nid, 'email', case when quiet and not p_urgent then 'suppressed_quiet_hours' else 'pending' end);
  end if;
  if p_push and pr.notify_push then
    insert into notification_deliveries (notification_id, channel, status)
    values (nid, 'push', case when quiet and not p_urgent then 'suppressed_quiet_hours' else 'pending' end);
  end if;
end $$;
revoke all on function enqueue_notification from public, anon, authenticated;

create function donor_can_see_request(p_request uuid, p_uid uuid) returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from blood_requests r join profiles d on d.id = p_uid
    where r.id = p_request and d.is_donor and d.onboarding_completed and d.deleted_at is null and d.suspended_at is null
      and d.availability <> 'not_available' and d.area_point is not null and r.location is not null
      and donor_matches(d.blood_group, r.blood_group, r.allow_compatible)
      and st_dwithin(d.area_point, r.location, least(r.current_radius_km, d.preferred_radius_km) * 1000))
$$;
revoke all on function donor_can_see_request from public, anon, authenticated;

create function notify_matching_donors(p_request uuid) returns void language plpgsql security definer set search_path = public as $$
declare r blood_requests; d record; conf boolean; urgent boolean;
begin
  select * into r from blood_requests where id = p_request;
  if not found or r.status not in ('pending_verification','active','partially_fulfilled') then return; end if;
  conf := r.confirmed_by is not null; urgent := is_urgent_verified(r);
  for d in
    select p.id from profiles p
    where p.is_donor and p.onboarding_completed and p.deleted_at is null and p.suspended_at is null
      and p.availability <> 'not_available' and p.area_point is not null and p.id is distinct from r.requester_id
      and donor_matches(p.blood_group, r.blood_group, r.allow_compatible)
      and st_dwithin(p.area_point, r.location, least(r.current_radius_km, p.preferred_radius_km) * 1000)
    order by st_distance(p.area_point, r.location)
    limit coalesce((cfg('matching')->>'max_donors_per_step')::int, 200)
  loop
    -- unconfirmed: in-app only. dedupe key differs before/after confirmation so confirmed alerts still go out.
    perform enqueue_notification(d.id, 'nearby_request',
      case when conf then 'Blood request nearby' else 'Unconfirmed blood request nearby' end,
      format('%s · %s unit(s) · %s%s', r.blood_group, r.units_required, r.hospital_name,
             case when conf then '' else ' · not yet confirmed by the facility' end),
      r.id, 'req:' || r.id || ':' || case when conf then 'c' else 'u' end || ':' || r.radius_step, conf, conf, urgent);
  end loop;
end $$;
revoke all on function notify_matching_donors from public, anon, authenticated;

-- ============ profile ============
create function complete_profile(p_name text, p_dob date, p_gender text, p_blood_group blood_group_t, p_phone text,
  p_area_label text, p_lat double precision, p_lng double precision, p_is_donor boolean, p_radius int)
returns void language plpgsql security definer set search_path = public as $$
declare g numeric := coalesce((cfg('location')->>'grid_degrees')::numeric, 0.01); pt geography;
        min_age int := coalesce((cfg('eligibility_gates')->>'min_account_age')::int, 13);
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  if length(trim(coalesce(p_name,''))) < 2 or length(p_name) > 80 then raise exception 'Enter your full name.'; end if;
  if p_dob is null or p_dob > (current_date - make_interval(years => min_age)) or p_dob < date '1900-01-01' then raise exception 'Enter a valid date of birth.'; end if;
  if p_phone !~ '^\+91[6-9][0-9]{9}$' then raise exception 'Enter a valid 10-digit Indian mobile number.'; end if;
  if length(trim(coalesce(p_area_label,''))) < 2 then raise exception 'Enter your area.'; end if;
  if p_lat is not null and p_lng is not null then   -- snapped inside the DB; the exact point is never written anywhere
    if p_lat not between 6 and 38 or p_lng not between 68 and 98 then raise exception 'Location is outside India.'; end if;
    pt := st_snaptogrid(st_setsrid(st_makepoint(p_lng, p_lat), 4326), g::float8)::geography;
  end if;
  update profiles set name = trim(p_name), date_of_birth = p_dob, gender = nullif(p_gender,''), blood_group = p_blood_group,
    phone = p_phone, area_label = trim(p_area_label), area_point = coalesce(pt, area_point), city = trim(p_area_label),
    is_donor = p_is_donor, availability = (case when p_is_donor then 'available_now' else 'not_available' end)::availability_t,
    preferred_radius_km = coalesce(p_radius, 10), onboarding_completed = true
  where id = auth.uid() and deleted_at is null;
end $$;
revoke all on function complete_profile from public, anon; grant execute on function complete_profile to authenticated;

create function set_my_area(p_label text, p_lat double precision, p_lng double precision) returns void
language plpgsql security definer set search_path = public as $$
declare g numeric := coalesce((cfg('location')->>'grid_degrees')::numeric, 0.01);
begin
  if p_lat not between 6 and 38 or p_lng not between 68 and 98 then raise exception 'Location is outside India.'; end if;
  update profiles set area_label = trim(p_label), city = trim(p_label),
    area_point = st_snaptogrid(st_setsrid(st_makepoint(p_lng, p_lat), 4326), g::float8)::geography where id = auth.uid();
end $$;
revoke all on function set_my_area from public, anon; grant execute on function set_my_area to authenticated;

create function add_self_reported_donation(p_date date) returns void language plpgsql security definer set search_path = public as $$
begin
  if p_date is null or p_date > current_date or p_date < date '1950-01-01' then raise exception 'Enter a valid past date.'; end if;
  insert into donation_history (donor_id, donation_date, source) values (auth.uid(), p_date, 'self_reported');
  update profiles set last_donation_date = greatest(coalesce(last_donation_date, p_date), p_date) where id = auth.uid();
end $$;
revoke all on function add_self_reported_donation from public, anon; grant execute on function add_self_reported_donation to authenticated;

-- ============ questionnaire (private; every non-owner read is audited) ============
create function my_questionnaire() returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_object('template', to_jsonb(t) - 'created_at', 'answers', q.answers, 'submitted_at', q.submitted_at)
  from questionnaire_templates t left join donor_health_questionnaires q on q.template_id = t.id and q.donor_id = auth.uid()
  where t.is_active
$$;
create function submit_questionnaire(p_answers jsonb) returns void language plpgsql security definer set search_path = public as $$
declare t questionnaire_templates;
begin
  select * into t from questionnaire_templates where is_active;
  if not found then raise exception 'No questionnaire is active.'; end if;
  if jsonb_typeof(p_answers) <> 'object' or length(p_answers::text) > 8000 then raise exception 'Invalid answers.'; end if;
  insert into donor_health_questionnaires (donor_id, template_id, answers) values (auth.uid(), t.id, p_answers)
  on conflict (donor_id, template_id) do update set answers = excluded.answers, submitted_at = now();
end $$;
revoke all on function my_questionnaire, submit_questionnaire from public, anon;
grant execute on function my_questionnaire, submit_questionnaire to authenticated;

-- ============ facilities ============
create function register_facility(p_name text, p_type text, p_address text, p_city text, p_state text, p_pincode text,
  p_phone text, p_email text, p_lat double precision, p_lng double precision) returns uuid
language plpgsql security definer set search_path = public as $$
declare fid uuid;
begin
  if not exists (select 1 from profiles where id = auth.uid() and onboarding_completed and suspended_at is null) then raise exception 'Complete your profile first.'; end if;
  insert into facilities (name, facility_type, address, city, state, pincode, contact_phone, contact_email, location, created_by)
  values (trim(p_name), p_type, trim(p_address), trim(p_city), trim(p_state), nullif(trim(p_pincode),''), p_phone, p_email,
          st_setsrid(st_makepoint(p_lng, p_lat), 4326)::geography, auth.uid()) returning id into fid;
  insert into facility_staff (facility_id, user_id, staff_role, added_by) values (fid, auth.uid(), 'manager', auth.uid());
  perform write_audit('facility_registered', 'facility', fid::text);
  return fid;
end $$;

create function register_facility_document(p_facility uuid, p_doc_type text, p_path text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_facility_member(p_facility) then raise exception 'Not allowed.'; end if;
  if split_part(p_path, '/', 1) <> p_facility::text then raise exception 'Invalid path.'; end if;
  insert into facility_documents (facility_id, doc_type, storage_path, uploaded_by) values (p_facility, p_doc_type, p_path, auth.uid());
end $$;

create function facility_private(p_id uuid) returns facilities language plpgsql stable security definer set search_path = public as $$
declare f facilities;
begin
  if not (is_facility_member(p_id) or has_role('verification_officer') or has_role('admin')) then raise exception 'Not allowed.'; end if;
  select * into f from facilities where id = p_id; return f;
end $$;

create function review_facility(p_id uuid, p_action text, p_reason text) returns void language plpgsql security definer set search_path = public as $$
declare f facilities; ttl int := coalesce((cfg('unconfirmed_request')->>'ttl_minutes')::int, 120);
begin
  if not (has_role('verification_officer') or has_role('admin')) then raise exception 'Not allowed.'; end if;
  if p_action in ('reject','suspend') and length(trim(coalesce(p_reason,''))) < 5 then raise exception 'A reason is required.'; end if;
  select * into f from facilities where id = p_id for update;
  if not found then raise exception 'Facility not found.'; end if;
  if p_action = 'approve' and f.status = 'pending' then
    update facilities set status = 'verified', verified_by = auth.uid(), verified_at = now(), rejection_reason = null where id = p_id;
  elsif p_action = 'reject' and f.status = 'pending' then
    update facilities set status = 'rejected', rejection_reason = p_reason where id = p_id;
  elsif p_action = 'suspend' and f.status = 'verified' then
    update facilities set status = 'suspended', suspended_reason = p_reason where id = p_id;
    -- confirmation is withdrawn: open requests go back to "unconfirmed" with the limited rules
    update blood_requests set status = 'pending_verification', confirmed_by = null, confirmed_at = null, radius_step = 0,
      current_radius_km = least(current_radius_km, (cfg('unconfirmed_request')->>'max_radius_km')::int),
      expires_at = least(now() + make_interval(mins => ttl), needed_at)
    where facility_id = p_id and status in ('active','partially_fulfilled');
  elsif p_action = 'restore' and f.status = 'suspended' then
    update facilities set status = 'verified', suspended_reason = null where id = p_id;
  else raise exception 'Invalid action % for a % facility.', p_action, f.status;
  end if;
  perform write_audit('facility_' || p_action, 'facility', p_id::text, p_reason);
end $$;

create function add_facility_staff(p_facility uuid, p_email text) returns void language plpgsql security definer set search_path = public as $$
declare uid uuid;
begin
  if not is_facility_manager(p_facility) then raise exception 'Only a verified facility manager can add staff.'; end if;
  select id into uid from auth.users where lower(email) = lower(trim(p_email));
  if uid is not null and exists (select 1 from profiles where id = uid) then
    insert into facility_staff (facility_id, user_id, added_by) values (p_facility, uid, auth.uid()) on conflict do nothing;
    perform write_audit('facility_staff_added', 'facility', p_facility::text);
  end if;   -- same response either way: no account-existence oracle
end $$;

-- ============ requests ============
create function create_request(p_facility uuid, p_blood_group blood_group_t, p_units int, p_component text, p_needed_at timestamptz,
  p_requester_phone text, p_relationship text, p_patient_name text, p_notes text, p_allow_compatible boolean)
returns uuid language plpgsql security definer set search_path = public as $$
declare me profiles; f facilities; rid uuid; staff boolean; u jsonb := cfg('unconfirmed_request'); lim jsonb := cfg('request_limits');
        steps jsonb := cfg('radius_escalation')->'steps_km'; st request_state_t; rad int; exp timestamptz;
begin
  select * into me from profiles where id = auth.uid();
  if not found or not me.onboarding_completed or me.deleted_at is not null then raise exception 'Complete your profile first.'; end if;
  if me.suspended_at is not null then raise exception 'Your account is suspended.'; end if;
  select * into f from facilities where id = p_facility;
  if not found or f.status <> 'verified' then raise exception 'Choose a verified hospital or blood bank.'; end if;
  if p_requester_phone !~ '^\+91[6-9][0-9]{9}$' then raise exception 'Enter a valid 10-digit Indian mobile number.'; end if;
  if p_needed_at <= now() or p_needed_at > now() + make_interval(days => (lim->>'max_days_ahead')::int) then raise exception 'Choose a needed time within the next % days.', lim->>'max_days_ahead'; end if;
  if not exists (select 1 from blood_components where code = p_component and active) then raise exception 'Choose a blood component.'; end if;
  if length(trim(coalesce(p_relationship,''))) < 2 then raise exception 'Enter your relationship to the patient.'; end if;
  if coalesce(p_notes,'') ~ '(\+?91)?[ -]?[6-9]([ -]?[0-9]){9}' or coalesce(p_patient_name,'') ~ '[0-9]{6,}' then
    raise exception 'Please do not put phone numbers in notes. Contact is arranged through LifeDrop.'; end if;
  if p_allow_compatible and not exists (select 1 from blood_compatibility) then raise exception 'Compatible-group matching is not configured yet.'; end if;
  if (select count(*) from blood_requests where requester_id = auth.uid() and created_at > now() - interval '24 hours') >= (lim->>'max_requests_per_24h')::int
    then raise exception 'Request limit reached. Try again later or contact the facility directly.'; end if;
  staff := is_facility_staff(p_facility);
  if not staff and (select count(*) from blood_requests where requester_id = auth.uid() and status = 'pending_verification') >= (u->>'max_open_per_account')::int
    then raise exception 'You already have an unconfirmed request open. Wait for the facility to confirm it or cancel it first.'; end if;
  if staff then st := 'active'; rad := (steps->>0)::int; exp := p_needed_at;
  else st := 'pending_verification'; rad := (u->>'max_radius_km')::int; exp := least(now() + make_interval(mins => (u->>'ttl_minutes')::int), p_needed_at); end if;
  insert into blood_requests (requester_id, blood_group, units_required, hospital_name, location, needed_at, additional_information, status,
      facility_id, component, relationship_to_patient, requester_phone, patient_name, allow_compatible, confirmed_by, confirmed_at,
      expires_at, current_radius_km, last_expanded_at)
  values (auth.uid(), p_blood_group, p_units, f.name, f.location, p_needed_at, nullif(trim(p_notes),''), st, p_facility, p_component,
      trim(p_relationship), p_requester_phone, nullif(trim(p_patient_name),''), p_allow_compatible,
      case when staff then auth.uid() end, case when staff then now() end, exp, rad, now())
  returning id into rid;
  if staff then perform write_audit('request_created_confirmed', 'request', rid::text); end if;
  perform notify_matching_donors(rid);
  return rid;
end $$;

create function confirm_request(p_request uuid) returns void language plpgsql security definer set search_path = public as $$
declare r blood_requests;
begin
  select * into r from blood_requests where id = p_request for update;
  if not found or not is_facility_staff(r.facility_id) then raise exception 'Not allowed.'; end if;
  if r.status <> 'pending_verification' or r.expires_at <= now() then raise exception 'This request can no longer be confirmed.'; end if;
  update blood_requests set status = 'active', confirmed_by = auth.uid(), confirmed_at = now(), expires_at = needed_at,
    radius_step = 0, current_radius_km = (cfg('radius_escalation')->'steps_km'->>0)::int, last_expanded_at = now() where id = p_request;
  perform write_audit('request_confirmed', 'request', p_request::text);
  perform enqueue_notification(r.requester_id, 'request_confirmed', 'Your request was confirmed',
    r.hospital_name || ' confirmed your request. Donors will now be alerted.', r.id, 'confirmed:' || r.id, true, false, false);
  perform notify_matching_donors(p_request);
end $$;

create function close_request_internal(p_request uuid, p_state request_state_t, p_reason text, p_action text) returns void
language plpgsql security definer set search_path = public as $$
begin
  update blood_requests set status = p_state, closed_reason = p_reason where id = p_request;
  perform write_audit(p_action, 'request', p_request::text, p_reason);
end $$;
revoke all on function close_request_internal from public, anon, authenticated;

create function cancel_request(p_request uuid, p_reason text) returns void language plpgsql security definer set search_path = public as $$
declare r blood_requests;
begin
  select * into r from blood_requests where id = p_request for update;
  if not found or not (r.requester_id = auth.uid() or is_facility_staff(r.facility_id)) then raise exception 'Not allowed.'; end if;
  if r.status not in ('pending_verification','active','partially_fulfilled') then raise exception 'This request is already closed.'; end if;
  perform close_request_internal(p_request, 'cancelled', coalesce(nullif(trim(p_reason),''), 'cancelled_by_owner'), 'request_cancelled');
  perform enqueue_notification(x.donor_id, 'request_cancelled', 'A request you responded to was cancelled', r.hospital_name, r.id, 'cancel:' || r.id, true, false, false)
    from request_responses x where x.request_id = p_request and x.status in ('accepted','selected');
end $$;

create function mark_fulfilled(p_request uuid) returns void language plpgsql security definer set search_path = public as $$
declare r blood_requests;
begin
  select * into r from blood_requests where id = p_request for update;
  if not found or not (r.requester_id = auth.uid() or is_facility_staff(r.facility_id)) then raise exception 'Not allowed.'; end if;
  if r.status not in ('active','partially_fulfilled') then raise exception 'Only a confirmed open request can be marked fulfilled.'; end if;
  update blood_requests set units_fulfilled = units_required where id = p_request;
  perform close_request_internal(p_request, 'fulfilled', 'marked_fulfilled', 'request_fulfilled');
end $$;

-- "still needed?" answer: extend the needed time (bounded) while the request is facility-confirmed
create function extend_request(p_request uuid, p_new_needed_at timestamptz) returns void language plpgsql security definer set search_path = public as $$
declare r blood_requests; lim jsonb := cfg('request_limits');
begin
  select * into r from blood_requests where id = p_request for update;
  if not found or not (r.requester_id = auth.uid() or is_facility_staff(r.facility_id)) then raise exception 'Not allowed.'; end if;
  if r.status not in ('active','partially_fulfilled') then raise exception 'Only confirmed open requests can be extended.'; end if;
  if r.extensions_used >= (lim->>'max_extensions')::int then raise exception 'Extension limit reached. Create a new request.'; end if;
  if p_new_needed_at <= r.needed_at or p_new_needed_at > now() + make_interval(days => (lim->>'max_days_ahead')::int) then raise exception 'Choose a later valid time.'; end if;
  update blood_requests set needed_at = p_new_needed_at, expires_at = p_new_needed_at, extensions_used = extensions_used + 1, renewal_prompted_at = null where id = p_request;
  perform write_audit('request_extended', 'request', p_request::text);
end $$;

-- ============ feed & responses ============
create function request_feed(p_id uuid default null)
returns table (id uuid, blood_group blood_group_t, units_required int, units_fulfilled int, component text, facility_name text, facility_city text,
  needed_at timestamptz, state request_state_t, verification text, is_urgent_verified boolean, additional_information text,
  distance_km numeric, is_mine boolean, is_facility boolean, my_response response_state_t, my_response_id uuid, expires_at timestamptz, needs_renewal boolean)
language sql stable security definer set search_path = public as $$
  select r.id, r.blood_group, r.units_required, r.units_fulfilled, r.component, f.name, f.city, r.needed_at, r.status,
    case when r.confirmed_by is not null then 'facility_confirmed' else 'unconfirmed' end,
    is_urgent_verified(r), r.additional_information,
    round((st_distance(r.location, (select area_point from profiles where id = auth.uid())) / 1000)::numeric, 1),
    r.requester_id = auth.uid(), is_facility_staff(r.facility_id),
    (select x.status from request_responses x where x.request_id = r.id and x.donor_id = auth.uid()),
    (select x.id from request_responses x where x.request_id = r.id and x.donor_id = auth.uid()), r.expires_at,
    r.renewal_prompted_at is not null and r.status in ('active','partially_fulfilled')
  from blood_requests r left join facilities f on f.id = r.facility_id
  where auth.uid() is not null and (p_id is null or r.id = p_id)
    and (r.requester_id = auth.uid() or is_facility_staff(r.facility_id)
         or (r.status in ('pending_verification','active','partially_fulfilled') and r.expires_at > now() and donor_can_see_request(r.id, auth.uid())))
  order by r.needed_at limit 100
$$;

create function respond_to_request(p_request uuid) returns void language plpgsql security definer set search_path = public as $$
declare me profiles; r blood_requests; g jsonb := cfg('eligibility_gates'); t questionnaire_templates;
begin
  select * into me from profiles where id = auth.uid();
  if not found or not me.onboarding_completed or me.deleted_at is not null then raise exception 'Complete your profile first.'; end if;
  if me.suspended_at is not null then raise exception 'Your account is suspended.'; end if;
  if not me.is_donor or me.availability = 'not_available' then raise exception 'Set yourself as available to donate first.'; end if;
  if me.phone_verified_at is null then raise exception 'PHONE_NOT_VERIFIED'; end if;
  if extract(year from age(current_date, me.date_of_birth)) < (g->>'min_donor_age')::int then raise exception 'You do not meet the minimum age to donate.'; end if;
  select * into t from questionnaire_templates where is_active;
  if not exists (select 1 from donor_health_questionnaires where donor_id = me.id and template_id = t.id) then raise exception 'QUESTIONNAIRE_REQUIRED'; end if;
  if (g->>'require_reviewed_questionnaire')::boolean and not t.medically_reviewed then
    raise exception 'Donor responses are paused until the health questionnaire has been medically reviewed.'; end if;
  select * into r from blood_requests where id = p_request for update;     -- serialises with fulfil/expire/cancel
  if not found then raise exception 'Request not found.'; end if;
  if r.requester_id = me.id then raise exception 'You cannot respond to your own request.'; end if;
  if r.status not in ('pending_verification','active','partially_fulfilled') or r.expires_at <= now() then raise exception 'This request is closed or has expired.'; end if;
  if not donor_can_see_request(p_request, me.id) then raise exception 'This request is outside your area, blood group or availability.'; end if;
  insert into request_responses (request_id, donor_id, status) values (p_request, me.id, 'accepted')
  on conflict (request_id, donor_id) do update set status = 'accepted', withdrawn_at = null
    where request_responses.status in ('withdrawn','declined');
  if not found then raise exception 'You have already responded to this request.'; end if;
  perform enqueue_notification(r.requester_id, 'donor_response', 'A donor can help',
    'A donor responded to your ' || r.blood_group || ' request at ' || r.hospital_name || '.', r.id, 'resp:' || r.id || ':' || me.id,
    r.confirmed_by is not null, false, false);
end $$;

create function withdraw_response(p_response uuid) returns void language plpgsql security definer set search_path = public as $$
declare x request_responses; r blood_requests;
begin
  select * into x from request_responses where id = p_response;
  if not found or x.donor_id is distinct from auth.uid() then raise exception 'Not allowed.'; end if;
  select * into r from blood_requests where id = x.request_id for update;
  if x.status not in ('accepted','selected') then raise exception 'Nothing to withdraw.'; end if;
  update request_responses set status = 'withdrawn', withdrawn_at = now() where id = p_response;
  perform enqueue_notification(r.requester_id, 'donor_withdrew', 'A donor withdrew', r.hospital_name, r.id, 'wd:' || p_response, r.confirmed_by is not null, false, false);
end $$;

create function request_responses_for(p_request uuid)
returns table (response_id uuid, donor_first_name text, blood_group blood_group_t, blood_group_verified boolean, distance_km numeric,
  availability availability_t, status response_state_t, created_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  if not exists (select 1 from blood_requests r where r.id = p_request and (r.requester_id = auth.uid() or is_facility_staff(r.facility_id))) then
    raise exception 'Not allowed.'; end if;
  return query
    select x.id, split_part(p.name, ' ', 1), p.blood_group, p.blood_group_verified_at is not null,
           round((st_distance(p.area_point, r.location) / 1000)::numeric, 0), p.availability, x.status, x.created_at
    from request_responses x join profiles p on p.id = x.donor_id join blood_requests r on r.id = x.request_id
    where x.request_id = p_request and x.status in ('accepted','selected','completed') order by x.created_at;
end $$;

create function select_donor(p_response uuid) returns void language plpgsql security definer set search_path = public as $$
declare x request_responses; r blood_requests;
begin
  select * into x from request_responses where id = p_response;
  if not found then raise exception 'Not found.'; end if;
  select * into r from blood_requests where id = x.request_id for update;
  if r.requester_id is distinct from auth.uid() then raise exception 'Not allowed.'; end if;
  if r.status not in ('pending_verification','active','partially_fulfilled') or r.expires_at <= now() then raise exception 'This request is closed.'; end if;
  if x.status <> 'accepted' then raise exception 'This response can no longer be selected.'; end if;
  if not exists (select 1 from profiles where id = x.donor_id and phone_verified_at is not null) then raise exception 'Donor phone is no longer verified.'; end if;
  if exists (select 1 from request_responses y join blood_requests q on q.id = y.request_id
             where y.donor_id = x.donor_id and y.status = 'selected' and y.id <> x.id and q.status in ('pending_verification','active','partially_fulfilled'))
    then raise exception 'This donor is already committed to another open request.'; end if;   -- no double commitments
  update request_responses set status = 'selected', selected_at = now() where id = p_response;
  perform enqueue_notification(x.donor_id, 'donor_selected', 'The requester chose you', 'Open the request to coordinate. Your number stays private.',
    r.id, 'sel:' || p_response, r.confirmed_by is not null, r.confirmed_by is not null, is_urgent_verified(r));
end $$;

create function reject_response(p_response uuid) returns void language plpgsql security definer set search_path = public as $$
declare x request_responses;
begin
  select * into x from request_responses where id = p_response;
  if not found or not exists (select 1 from blood_requests where id = x.request_id and requester_id = auth.uid()) then raise exception 'Not allowed.'; end if;
  update request_responses set status = 'declined' where id = p_response and status in ('accepted','selected');
end $$;

-- facility records that the donation physically happened. Idempotent per response; safe if request expired meanwhile.
create function confirm_donation(p_response uuid) returns void language plpgsql security definer set search_path = public as $$
declare x request_responses; r blood_requests;
begin
  select * into x from request_responses where id = p_response;
  if not found then raise exception 'Not found.'; end if;
  select * into r from blood_requests where id = x.request_id for update;
  if not is_facility_staff(r.facility_id) then raise exception 'Not allowed.'; end if;
  if x.status not in ('accepted','selected') then raise exception 'This response cannot be confirmed.'; end if;
  insert into donation_history (donor_id, donation_date, facility_id, request_id, response_id, source, confirmed_by, confirmed_at)
  values (x.donor_id, (now() at time zone 'Asia/Kolkata')::date, r.facility_id, r.id, x.id, 'facility_confirmed', auth.uid(), now());  -- unique(response_id) blocks duplicates
  update request_responses set status = 'completed' where id = p_response;
  update profiles set last_donation_date = (now() at time zone 'Asia/Kolkata')::date where id = x.donor_id;
  if r.status in ('active','partially_fulfilled') then
    update blood_requests set units_fulfilled = units_fulfilled + 1,
      status = (case when units_fulfilled + 1 >= units_required then 'fulfilled' else 'partially_fulfilled' end)::request_state_t,
      closed_reason = case when units_fulfilled + 1 >= units_required then 'all_units_confirmed' end where id = r.id;
  end if;
  perform write_audit('donation_confirmed', 'response', p_response::text);
  perform enqueue_notification(x.donor_id, 'donation_confirmed', 'Thank you', 'The facility recorded your donation.', r.id, 'don:' || p_response, true, false, false);
end $$;

-- blood-group verification is performed by the facility at donation time (process to be confirmed by you)
create function verify_donor_blood_group(p_response uuid) returns void language plpgsql security definer set search_path = public as $$
declare x request_responses; r blood_requests;
begin
  select * into x from request_responses where id = p_response;
  select * into r from blood_requests where id = x.request_id;
  if not found or not is_facility_staff(r.facility_id) then raise exception 'Not allowed.'; end if;
  update profiles set blood_group_verified_at = now(), blood_group_verified_by = auth.uid() where id = x.donor_id;
  perform write_audit('blood_group_verified', 'response', p_response::text);
end $$;

-- audited access to the private health answers
create function facility_read_questionnaire(p_response uuid) returns jsonb language plpgsql security definer set search_path = public as $$
declare x request_responses; r blood_requests; out jsonb;
begin
  select * into x from request_responses where id = p_response;
  select * into r from blood_requests where id = x.request_id;
  if not found or not is_facility_staff(r.facility_id) or x.status not in ('accepted','selected','completed') then raise exception 'Not allowed.'; end if;
  select jsonb_build_object('questions', t.questions, 'answers', q.answers, 'reviewed', t.medically_reviewed) into out
  from donor_health_questionnaires q join questionnaire_templates t on t.id = q.template_id where q.donor_id = x.donor_id order by q.submitted_at desc limit 1;
  perform write_audit('questionnaire_read', 'response', p_response::text, 'facility donation review');
  return out;
end $$;
create function admin_read_questionnaire(p_donor uuid, p_reason text) returns jsonb language plpgsql security definer set search_path = public as $$
declare out jsonb;
begin
  if not (has_role('admin') or has_role('verification_officer')) then raise exception 'Not allowed.'; end if;
  if length(trim(coalesce(p_reason,''))) < 10 then raise exception 'State the operational reason (10+ characters).'; end if;
  select jsonb_build_object('questions', t.questions, 'answers', q.answers) into out
  from donor_health_questionnaires q join questionnaire_templates t on t.id = q.template_id where q.donor_id = p_donor order by q.submitted_at desc limit 1;
  perform write_audit('questionnaire_read_admin', 'profile', p_donor::text, p_reason);
  return out;
end $$;

-- ============ reports & moderation ============
create function report_request(p_request uuid, p_reason text, p_details text) returns void language plpgsql security definer set search_path = public as $$
declare lim jsonb := cfg('reports');
begin
  if not exists (select 1 from blood_requests where id = p_request and requester_id is distinct from auth.uid()) then raise exception 'You cannot report this request.'; end if;
  if (select count(*) from reports where reporter_id = auth.uid() and created_at > now() - interval '24 hours') >= (lim->>'max_reports_per_day')::int then raise exception 'Report limit reached.'; end if;
  insert into reports (request_id, reporter_id, reason, details) values (p_request, auth.uid(), p_reason, left(p_details, 500))
  on conflict (request_id, reporter_id) do nothing;   -- every report goes to the moderator queue; nothing is auto-hidden
end $$;

create function moderation_queue() returns table (report_id uuid, request_id uuid, reason text, details text, reported_at timestamptz,
  distinct_reporters bigint, priority boolean, blood_group blood_group_t, units int, facility_name text, request_state request_state_t, confirmed boolean)
language plpgsql stable security definer set search_path = public as $$
begin
  if not (has_role('moderator') or has_role('admin')) then raise exception 'Not allowed.'; end if;
  return query select rp.id, rp.request_id, rp.reason, rp.details, rp.created_at,
    (select count(distinct x.reporter_id) from reports x where x.request_id = rp.request_id and x.status = 'open'),
    (select count(distinct x.reporter_id) from reports x where x.request_id = rp.request_id and x.status = 'open') >= (cfg('reports')->>'priority_after_reporters')::int,
    r.blood_group, r.units_required, r.hospital_name, r.status, r.confirmed_by is not null
  from reports rp join blood_requests r on r.id = rp.request_id where rp.status = 'open' order by 6 desc, rp.created_at;
end $$;

create function moderate_report(p_report uuid, p_action text, p_reason text) returns void language plpgsql security definer set search_path = public as $$
declare rp reports;
begin
  if not (has_role('moderator') or has_role('admin')) then raise exception 'Not allowed.'; end if;
  if length(trim(coalesce(p_reason,''))) < 5 then raise exception 'A reason is required.'; end if;
  select * into rp from reports where id = p_report for update;
  if not found or rp.status <> 'open' then raise exception 'Report is not open.'; end if;
  if p_action = 'cancel_request' then
    perform 1 from blood_requests where id = rp.request_id and status in ('pending_verification','active','partially_fulfilled') for update;
    if found then perform close_request_internal(rp.request_id, 'cancelled', 'moderation', 'request_cancelled_by_moderator'); end if;
  elsif p_action not in ('resolve','dismiss') then raise exception 'Unknown action.'; end if;
  update reports set status = (case when p_action = 'dismiss' then 'dismissed' else 'resolved' end)::report_status_t, resolved_by = auth.uid(), resolved_at = now(), resolution = p_reason
   where request_id = rp.request_id and status = 'open';
  insert into moderation_actions (report_id, request_id, moderator_id, action, reason) values (p_report, rp.request_id, auth.uid(), p_action, p_reason);
  perform write_audit('moderation_' || p_action, 'report', p_report::text, p_reason);
end $$;

-- ============ admin ============
create function set_user_role(p_user uuid, p_role platform_role_t, p_grant boolean, p_reason text) returns void language plpgsql security definer set search_path = public as $$
begin
  if not has_role('admin') then raise exception 'Not allowed.'; end if;
  if p_user = auth.uid() and not p_grant then raise exception 'Admins cannot remove their own role.'; end if;
  if p_grant then insert into user_roles (user_id, role, granted_by) values (p_user, p_role, auth.uid()) on conflict do nothing;
  else delete from user_roles where user_id = p_user and role = p_role; end if;
  perform write_audit('role_' || case when p_grant then 'granted' else 'revoked' end, 'profile', p_user::text, p_reason, jsonb_build_object('role', p_role));
end $$;
create function set_user_suspended(p_user uuid, p_suspend boolean, p_reason text) returns void language plpgsql security definer set search_path = public as $$
begin
  if not has_role('admin') then raise exception 'Not allowed.'; end if;
  update profiles set suspended_at = case when p_suspend then now() end where id = p_user;
  perform write_audit(case when p_suspend then 'user_suspended' else 'user_restored' end, 'profile', p_user::text, p_reason);
end $$;
create function set_app_config(p_key text, p_value jsonb, p_reason text) returns void language plpgsql security definer set search_path = public as $$
begin
  if not has_role('admin') then raise exception 'Not allowed.'; end if;
  update app_config set value = p_value, updated_by = auth.uid(), updated_at = now() where key = p_key;
  perform write_audit('config_changed', 'config', p_key, p_reason, jsonb_build_object('new_value', p_value));
end $$;

create function mark_notifications_read(p_ids uuid[]) returns void language sql security definer set search_path = public as $$
  update notifications set read_at = now() where user_id = auth.uid() and read_at is null and (p_ids is null or id = any (p_ids))
$$;

-- real counts only, nothing shown when zero
create function public_stats() returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_strip_nulls(jsonb_build_object(
    'registered_donors', nullif((select count(*) from profiles where is_donor and onboarding_completed and deleted_at is null), 0),
    'fulfilled_requests', nullif((select count(*) from blood_requests where status = 'fulfilled'), 0),
    'verified_facilities', nullif((select count(*) from facilities where status = 'verified'), 0)))
$$;

-- ============ scheduled maintenance (service role / cron only) ============
create function run_request_maintenance() returns jsonb language plpgsql security definer set search_path = public as $$
declare r blood_requests; n_exp int := 0; n_prompt int := 0; n_rad int := 0; n_esc int := 0; rs jsonb := cfg('radius_escalation'); steps int := jsonb_array_length(cfg('radius_escalation')->'steps_km');
        prompt_min int := (cfg('request_limits')->>'still_needed_prompt_minutes')::int;
begin
  for r in select * from blood_requests where status = 'pending_verification' and expires_at <= now() for update skip locked loop
    perform close_request_internal(r.id, 'expired', 'unconfirmed_timeout', 'request_expired'); n_exp := n_exp + 1;
    perform enqueue_notification(r.requester_id, 'request_expired', 'Your request expired unconfirmed', 'No facility confirmed it in time. Contact the facility directly and create a new request if you still need blood.', r.id, 'exp:' || r.id, true, false, false);
  end loop;
  for r in select * from blood_requests where status in ('active','partially_fulfilled') and needed_at <= now() for update skip locked loop
    perform close_request_internal(r.id, 'expired', 'needed_time_passed', 'request_expired'); n_exp := n_exp + 1;
  end loop;
  for r in select * from blood_requests where status in ('active','partially_fulfilled') and renewal_prompted_at is null
           and needed_at <= now() + make_interval(mins => prompt_min) for update skip locked loop
    update blood_requests set renewal_prompted_at = now() where id = r.id; n_prompt := n_prompt + 1;
    perform enqueue_notification(r.requester_id, 'still_needed', 'Is blood still needed?', 'Your request at ' || r.hospital_name || ' is about to expire. Confirm if you still need it.', r.id, 'prompt:' || r.id || ':' || r.extensions_used, true, true, true);
  end loop;
  for r in select * from blood_requests where status in ('active','partially_fulfilled') and radius_step < steps - 1
           and coalesce(last_expanded_at, confirmed_at) + make_interval(mins => (rs->>'step_interval_minutes')::int) <= now()
           and not exists (select 1 from request_responses x where x.request_id = blood_requests.id and x.status in ('accepted','selected','completed')) for update skip locked loop
    update blood_requests set radius_step = radius_step + 1, current_radius_km = (rs->'steps_km'->>(r.radius_step + 1))::int, last_expanded_at = now() where id = r.id;
    perform notify_matching_donors(r.id); n_rad := n_rad + 1;
  end loop;
  for r in select * from blood_requests where status in ('active','partially_fulfilled') and escalated_at is null
           and radius_step >= (rs->>'escalate_admin_after_step')::int
           and not exists (select 1 from request_responses x where x.request_id = blood_requests.id and x.status in ('accepted','selected','completed')) for update skip locked loop
    update blood_requests set escalated_at = now() where id = r.id; n_esc := n_esc + 1;
    perform enqueue_notification(ur.user_id, 'escalation', 'Request needs escalation', 'No donor has responded to a confirmed request at ' || r.hospital_name, r.id, 'esc:' || r.id, true, false, true)
      from user_roles ur where ur.role = 'admin';
    perform write_audit('request_escalated', 'request', r.id::text, 'no response after radius expansion');
  end loop;
  return jsonb_build_object('expired', n_exp, 'renewal_prompts', n_prompt, 'radius_expansions', n_rad, 'escalations', n_esc);
end $$;
revoke all on function run_request_maintenance from public, anon, authenticated;

-- ============ account deletion: scrub, unlink, then the server route deletes the auth identity ============
create function anonymize_account(p_uid uuid) returns void language plpgsql security definer set search_path = public as $$
declare r blood_requests;
begin
  for r in select * from blood_requests where requester_id = p_uid and status in ('pending_verification','active','partially_fulfilled') for update loop
    perform close_request_internal(r.id, 'cancelled', 'requester_deleted_account', 'request_closed_on_account_deletion');
  end loop;
  update request_responses set status = 'withdrawn', withdrawn_at = now() where donor_id = p_uid and status in ('accepted','selected');
  update blood_requests set requester_phone = null, patient_name = null, additional_information = null, relationship_to_patient = null where requester_id = p_uid;
  delete from donor_health_questionnaires where donor_id = p_uid;
  delete from facility_staff where user_id = p_uid;
  perform set_config('app.anonymizing', 'on', true);
  update audit_logs set actor_id = null where actor_id = p_uid;
  update audit_logs set entity_id = null, metadata = '{}' where entity_type = 'profile' and entity_id = p_uid::text;
  insert into deletion_records default values;
  -- FKs are ON DELETE SET NULL for requests/responses/donations/reports, so deleting auth.users (done by the server route) unlinks them.
end $$;
revoke all on function anonymize_account from public, anon, authenticated;

-- ============ grants for client-callable functions ============
revoke all on function create_request, confirm_request, cancel_request, mark_fulfilled, extend_request, request_feed, respond_to_request,
  withdraw_response, request_responses_for, select_donor, reject_response, confirm_donation, verify_donor_blood_group, facility_read_questionnaire,
  admin_read_questionnaire, report_request, moderation_queue, moderate_report, set_user_role, set_user_suspended, set_app_config,
  mark_notifications_read, register_facility, register_facility_document, facility_private, review_facility, add_facility_staff from public, anon;
grant execute on function create_request, confirm_request, cancel_request, mark_fulfilled, extend_request, request_feed, respond_to_request,
  withdraw_response, request_responses_for, select_donor, reject_response, confirm_donation, verify_donor_blood_group, facility_read_questionnaire,
  admin_read_questionnaire, report_request, moderation_queue, moderate_report, set_user_role, set_user_suspended, set_app_config,
  mark_notifications_read, register_facility, register_facility_document, facility_private, review_facility, add_facility_staff to authenticated;
revoke all on function public_stats from public;
grant execute on function public_stats to anon, authenticated;
