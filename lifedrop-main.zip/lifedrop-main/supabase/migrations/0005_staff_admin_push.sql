-- LifeDrop 0005: staff listing, admin lookup, push subscriptions. NOT executed in the authoring environment.

create function facility_staff_list(p_facility uuid) returns table (user_id uuid, first_name text, staff_role text, is_me boolean)
language plpgsql stable security definer set search_path = public as $$
begin
  if not is_facility_member(p_facility) then raise exception 'Not allowed.'; end if;
  return query select s.user_id, split_part(p.name, ' ', 1), s.staff_role, s.user_id = auth.uid()
    from facility_staff s join profiles p on p.id = s.user_id where s.facility_id = p_facility order by s.created_at;
end $$;

create function remove_facility_staff(p_facility uuid, p_user uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  if not is_facility_manager(p_facility) then raise exception 'Only a verified facility manager can remove staff.'; end if;
  if p_user = auth.uid() then raise exception 'Managers cannot remove themselves.'; end if;
  delete from facility_staff where facility_id = p_facility and user_id = p_user;
  perform write_audit('facility_staff_removed', 'facility', p_facility::text);
end $$;

-- Admin lookup by exact email (no fuzzy search, no listing). Audited because it reveals an account's existence.
create function admin_find_user(p_email text, p_reason text) returns table (user_id uuid, name text, donor_code text, suspended boolean, roles text)
language plpgsql security definer set search_path = public as $$
begin
  if not has_role('admin') then raise exception 'Not allowed.'; end if;
  if length(trim(coalesce(p_reason,''))) < 5 then raise exception 'A reason is required.'; end if;
  perform write_audit('admin_user_lookup', 'profile', null, p_reason);
  return query select p.id, p.name, p.donor_code, p.suspended_at is not null,
      (select string_agg(r.role::text, ',') from user_roles r where r.user_id = p.id)
    from auth.users u join profiles p on p.id = u.id where lower(u.email) = lower(trim(p_email));
end $$;

create function save_push_subscription(p_endpoint text, p_p256dh text, p_auth text) returns void language sql security definer set search_path = public as $$
  insert into push_subscriptions (user_id, endpoint, p256dh, auth) values (auth.uid(), p_endpoint, p_p256dh, p_auth)
  on conflict (endpoint) do update set user_id = auth.uid(), p256dh = excluded.p256dh, auth = excluded.auth
$$;
create function delete_push_subscription(p_endpoint text) returns void language sql security definer set search_path = public as $$
  delete from push_subscriptions where endpoint = p_endpoint and user_id = auth.uid()
$$;

revoke all on function facility_staff_list, remove_facility_staff, admin_find_user, save_push_subscription, delete_push_subscription from public, anon;
grant execute on function facility_staff_list, remove_facility_staff, admin_find_user, save_push_subscription, delete_push_subscription to authenticated;
