-- DB-level tests for the critical workflows. Run against a DISPOSABLE database after applying migrations 0001-0004
-- (e.g. `supabase db reset && psql "$SUPABASE_DB_URL" -f supabase/tests/workflow.sql`). Everything runs in one transaction and rolls back.
-- NOT executed by the author (no Postgres in the authoring environment): treat a first run as part of review.
begin;
create or replace function _as(uid uuid) returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claims', json_build_object('sub', uid, 'role','authenticated')::text, true);
  execute 'set local role authenticated'; end $$;
create or replace function _su() returns void language plpgsql as $$ begin execute 'reset role'; end $$;
create or replace function _expect_error(q text, frag text) returns void language plpgsql as $$ begin
  begin execute q; raise exception 'EXPECTED ERROR CONTAINING % BUT NONE RAISED: %', frag, q;
  exception when others then if sqlerrm not like '%' || frag || '%' then raise exception 'wrong error for %: %', q, sqlerrm; end if; end; end $$;

-- fixtures (service-level)
insert into auth.users (id, email) values
 ('00000000-0000-0000-0000-0000000000a1','req@t.test'),('00000000-0000-0000-0000-0000000000a2','donor@t.test'),('00000000-0000-0000-0000-0000000000a3','far@t.test'),
 ('00000000-0000-0000-0000-0000000000b1','staff@t.test'),('00000000-0000-0000-0000-0000000000c1','mod@t.test'),('00000000-0000-0000-0000-0000000000d1','admin@t.test'),('00000000-0000-0000-0000-0000000000e1','other@t.test');
update profiles set name='Req Er', date_of_birth='1990-01-01', phone='+919000000001', blood_group='O+', onboarding_completed=true where id='00000000-0000-0000-0000-0000000000a1';
update profiles set name='Dona Tor', date_of_birth='1990-01-01', phone='+919000000002', phone_verified_at=now(), blood_group='O+', is_donor=true, availability='available_now', preferred_radius_km=25, onboarding_completed=true,
  area_point=st_setsrid(st_makepoint(79.55,13.44),4326)::geography where id='00000000-0000-0000-0000-0000000000a2';          -- ~3 km from facility
update profiles set name='Far Away', date_of_birth='1990-01-01', phone='+919000000003', phone_verified_at=now(), blood_group='O+', is_donor=true, availability='available_now', preferred_radius_km=25, onboarding_completed=true,
  area_point=st_setsrid(st_makepoint(79.75,13.44),4326)::geography where id='00000000-0000-0000-0000-0000000000a3';          -- ~24 km
update profiles set name='Staff', date_of_birth='1990-01-01', phone='+919000000004', onboarding_completed=true where id='00000000-0000-0000-0000-0000000000b1';
update profiles set onboarding_completed=true, name='Other', date_of_birth='1990-01-01', phone='+919000000005', blood_group='A+' where id='00000000-0000-0000-0000-0000000000e1';
insert into user_roles values ('00000000-0000-0000-0000-0000000000c1','moderator'), ('00000000-0000-0000-0000-0000000000d1','admin');
insert into facilities (id,name,facility_type,address,city,state,location,status) values
 ('11111111-1111-1111-1111-111111111111','Test Hospital','hospital','1 Test Rd','Testville','TS',st_setsrid(st_makepoint(79.52,13.44),4326)::geography,'verified'),
 ('22222222-2222-2222-2222-222222222222','Pending Clinic','clinic','2 Test Rd','Testville','TS',st_setsrid(st_makepoint(79.52,13.44),4326)::geography,'pending');
insert into facility_staff values ('11111111-1111-1111-1111-111111111111','00000000-0000-0000-0000-0000000000b1','manager',null,now());
update questionnaire_templates set medically_reviewed = true where is_active;      -- test-only
insert into donor_health_questionnaires (donor_id, template_id, answers) select p, t.id, '{"tobacco":{"v":"no"}}' from (values ('00000000-0000-0000-0000-0000000000a2'::uuid),('00000000-0000-0000-0000-0000000000a3')) v(p), questionnaire_templates t where t.is_active;

-- 1) RLS: clients cannot read requests/questionnaires directly, cannot see other profiles, cannot self-grant roles
select _as('00000000-0000-0000-0000-0000000000e1');
select _expect_error($$select * from blood_requests$$, 'permission denied');
select _expect_error($$select * from donor_health_questionnaires$$, 'permission denied');
select _expect_error($$insert into user_roles values ('00000000-0000-0000-0000-0000000000e1','admin')$$, 'permission denied');
select _expect_error($$update profiles set donor_code='HACK' where id='00000000-0000-0000-0000-0000000000e1'$$, 'permission denied');
do $$ begin assert (select count(*) from profiles) = 1, 'user must see only own profile'; end $$;

-- 2) unverified facility cannot be chosen; unconfirmed request rules
select _as('00000000-0000-0000-0000-0000000000a1');
select _expect_error($$select create_request('22222222-2222-2222-2222-222222222222','O+',1,'whole_blood',now()+interval '5 hours','+919000000001','son',null,null,false)$$, 'verified hospital');
select _expect_error($$select create_request('11111111-1111-1111-1111-111111111111','O+',1,'whole_blood',now()+interval '5 hours','+919000000001','son',null,'call 9876543210',false)$$, 'phone numbers');
create temp table t_req as select create_request('11111111-1111-1111-1111-111111111111','O+',2,'whole_blood',now()+interval '5 hours','+919000000001','son',null,null,false) as id;
select _su();
do $$ declare r blood_requests; begin select * into r from blood_requests where id=(select id from t_req);
  assert r.status='pending_verification', 'must start unconfirmed'; assert r.current_radius_km=5, 'unconfirmed radius is 5 km';
  assert r.expires_at <= now()+interval '121 minutes', 'unconfirmed expires in 2h';
  assert not is_urgent_verified(r), 'unconfirmed can never be urgent-verified'; end $$;
select _as('00000000-0000-0000-0000-0000000000a1');
select _expect_error($$select create_request('11111111-1111-1111-1111-111111111111','O+',1,'whole_blood',now()+interval '5 hours','+919000000001','son',null,null,false)$$, 'unconfirmed request open');

-- 3) limited matching: in-app only, 5 km (near donor notified, far donor not)
select _su();
do $$ begin
  assert exists (select 1 from notifications where user_id='00000000-0000-0000-0000-0000000000a2' and kind='nearby_request'), 'near donor gets in-app alert';
  assert not exists (select 1 from notifications where user_id='00000000-0000-0000-0000-0000000000a3' and kind='nearby_request'), 'far donor (24 km) not alerted while unconfirmed';
  assert not exists (select 1 from notification_deliveries), 'no email/push for unconfirmed requests'; end $$;

-- 4) donor acceptance: visible only in range; far donor rejected
select _as('00000000-0000-0000-0000-0000000000a3');
select _expect_error(format($$select respond_to_request(%L)$$, (select id from t_req)), 'outside your area');
select _as('00000000-0000-0000-0000-0000000000a2');
select respond_to_request((select id from t_req));
select _expect_error(format($$select respond_to_request(%L)$$, (select id from t_req)), 'already responded');

-- 5) only facility staff can confirm; confirmation -> active + wider radius notifications w/ channels
select _as('00000000-0000-0000-0000-0000000000e1');
select _expect_error(format($$select confirm_request(%L)$$, (select id from t_req)), 'Not allowed');
select _as('00000000-0000-0000-0000-0000000000b1');
select confirm_request((select id from t_req));
select _su();
do $$ begin assert (select status from blood_requests where id=(select id from t_req))='active'; assert exists (select 1 from notification_deliveries); end $$;

-- 6) requester sees donor without phone; selects; double commitment blocked; contact data never exposed
select _as('00000000-0000-0000-0000-0000000000a1');
create temp table t_resp as select response_id from request_responses_for((select id from t_req));
select select_donor((select response_id from t_resp));
select _su();
do $$ begin assert (select count(*) from request_responses_for((select id from t_req)) ) >= 0; end $$;   -- column list itself has no phone/email: see function signature

-- 7) facility confirms donation once; units & state advance; duplicate blocked
select _as('00000000-0000-0000-0000-0000000000b1');
select confirm_donation((select response_id from t_resp));
select _expect_error(format($$select confirm_donation(%L)$$, (select response_id from t_resp)), 'cannot be confirmed');
select _su();
do $$ begin assert (select status from blood_requests where id=(select id from t_req))='partially_fulfilled'; assert (select units_fulfilled from blood_requests where id=(select id from t_req))=1; end $$;

-- 8) state machine
select _expect_error(format($$update blood_requests set status='active' where id=%L and status='partially_fulfilled'$$, (select id from t_req)), ''); -- allowed? partially->active is NOT allowed
-- 9) health questionnaire: staff read is audited; others are denied
select _as('00000000-0000-0000-0000-0000000000e1');
select _expect_error(format($$select facility_read_questionnaire(%L)$$, (select response_id from t_resp)), 'Not allowed');
select _as('00000000-0000-0000-0000-0000000000b1');
select facility_read_questionnaire((select response_id from t_resp));
select _su();
do $$ begin assert exists (select 1 from audit_logs where action='questionnaire_read'), 'read must be audited'; end $$;

-- 10) reports -> moderator queue (no auto-hide); audit immutable
select _as('00000000-0000-0000-0000-0000000000e1');
select report_request((select id from t_req), 'spam', 'test');
select _as('00000000-0000-0000-0000-0000000000c1');
do $$ begin assert (select count(*) from moderation_queue()) = 1; end $$;
select _su();
do $$ begin assert (select status from blood_requests where id=(select id from t_req)) <> 'cancelled', 'reports must not auto-hide'; end $$;
select _expect_error($$update audit_logs set action='x'$$, 'append-only');

-- 11) quiet hours + urgent bypass are server-decided
do $$ begin
  assert in_quiet_hours(timestamptz '2026-10-01 23:00+05:30'), '11pm IST is quiet';
  assert not in_quiet_hours(timestamptz '2026-10-01 12:00+05:30'), 'noon IST is not quiet';
  assert in_quiet_hours(timestamptz '2026-10-01 06:59+05:30') and not in_quiet_hours(timestamptz '2026-10-01 07:00+05:30'); end $$;

-- 12) public stats only real counts
select _as('00000000-0000-0000-0000-0000000000e1');
do $$ begin assert (select public_stats() ? 'fulfilled_requests') = false, 'zero fulfilled must be omitted'; end $$;

rollback;
select 'workflow tests passed' as result;
