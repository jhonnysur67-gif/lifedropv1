import type { Config } from "tailwindcss";
export default { content: ["./src/**/*.{ts,tsx}"], theme: { extend: { colors: { brand: { DEFAULT: "#C8102E", dark: "#A50D26", soft: "#FDECEF" } } } }, plugins: [] } satisfies Config;
