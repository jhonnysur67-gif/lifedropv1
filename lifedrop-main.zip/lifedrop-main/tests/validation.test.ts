import test from "node:test";
import assert from "node:assert/strict";
import { isIndianMobile, looksLikePhoneInText, isSixDigitCode, isUuid, toE164 } from "../src/lib/validation.ts";

test("indian mobile", () => { assert.ok(isIndianMobile("9876543210")); assert.ok(!isIndianMobile("1234567890")); assert.ok(!isIndianMobile("98765")); assert.equal(toE164("9876543210"), "+919876543210"); });
test("phone smuggling in notes is detected", () => {
  for (const s of ["call 9876543210", "call +91 98765 43210", "98765-43210 urgent", "my no is 91 9876543210"]) assert.ok(looksLikePhoneInText(s), s);
  for (const t of ["Ward 4, bed 12", "needs 2 units by 6pm"]) assert.ok(!looksLikePhoneInText(t), t);
});
test("otp + uuid", () => { assert.ok(isSixDigitCode("012345")); assert.ok(!isSixDigitCode("12345")); assert.ok(!isSixDigitCode("12345a")); assert.ok(isUuid("123e4567-e89b-12d3-a456-426614174000")); assert.ok(!isUuid("x")); });
